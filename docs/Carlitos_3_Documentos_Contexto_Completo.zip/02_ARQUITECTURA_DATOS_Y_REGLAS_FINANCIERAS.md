# Panadería Carlitos — Arquitectura técnica, datos y motor financiero

**Versión:** propuesta de implementación para tres desarrolladores en cuatro semanas. **Stack:** Python, Django, PostgreSQL, HTML/CSS/JavaScript, Chart.js. **Datos:** simulados. **Moneda:** USD. **Precisión:** Decimal.

## 1. Decisión de arquitectura

Se implementará un **monolito modular Django**, no microservicios. Tres capas lógicas: **presentación** (templates, CSS, JavaScript, gráficos), **aplicación/dominio** (vistas, formularios, servicios contables y financieros, autorización), **persistencia** (ORM Django y PostgreSQL). Las vistas coordinan; los servicios calculan; los modelos almacenan; las plantillas no calculan saldos oficiales.

### Flujo de extremo a extremo

```mermaid
flowchart TD
 A[Excel simulado] --> B[Validación y previsualización]
 B --> C{¿Asientos balanceados y cuentas válidas?}
 C -->|No| D[Errores por fila y rechazo del lote]
 C -->|Sí| E[Asientos y detalle en PostgreSQL]
 E --> F[Libro mayor y balanza]
 F --> G[3 estados históricos]
 G --> H[Presupuestos y supuestos]
 H --> I[Pronósticos y escenarios]
 I --> J[Cédulas de saldos proyectados]
 J --> K{¿Cuadran balance y patrimonio?}
 K -->|No| L[Diagnóstico y corrección]
 K -->|Sí| M[3 estados proyectados]
 M --> N[Indicadores y exportaciones]
```

## 2. Estructura de repositorio sugerida

```text
carlitos_finanzas/
  manage.py
  config/                 # settings, urls, wsgi/asgi
  apps/
    usuarios/             # login, perfiles, permisos
    catalogo/             # cuentas, períodos, cierres
    contabilidad/         # asientos, detalles, importación
    estados_historicos/   # consultas y presentación
    presupuestos/         # versiones y líneas mensuales
    pronosticos/          # escenarios y supuestos
    proyecciones/         # motor de saldos futuros
    analisis/             # indicadores, dashboard, exportaciones
    auditoria/            # servicio transversal, sin menú autónomo
  templates/              # base.html y plantillas por módulo
  static/css/             # tokens.css, layout.css, componentes.css
  static/js/              # filtros, gráficos, formularios
  media/importaciones/    # archivos autorizados, no públicos
  tests/                  # pruebas de dominio e integración
  docs/                   # especificaciones y diagramas
```

No crear una aplicación Django por cada pantalla. Un módulo funcional puede contener varias vistas.

## 3. Modelo relacional base: doce entidades

El documento técnico fuente identifica estas entidades. En la implementación se pueden añadir campos operativos necesarios sin convertirlos en módulos adicionales.

| Entidad | Campos recomendados | Reglas |
|---|---|---|
| `usuario` | Django User, perfil, rol, activo | autenticación y autorización |
| `periodo` | año, mes, inicio, fin, estado, cerrado_por | año+mes único; abierto/cerrado |
| `cuenta` | código, nombre, padre_id, naturaleza, clase, nivel, acepta_movimiento, activa | código único; padre válido |
| `lote_importacion` | archivo, hash, usuario, fecha, estado, resumen | evitar duplicados; auditar |
| `asiento` | número, fecha, periodo_id, lote_id, descripción, estado | número único en período |
| `detalle_asiento` | asiento_id, cuenta_id, debe, haber, orden | solo cuenta de movimiento |
| `presupuesto` | año, versión, estado, responsable, fecha_aprobación | versión identificable |
| `presupuesto_linea` | presupuesto_id, mes, cuenta_id, importe | unicidad por combinación |
| `escenario` | nombre, versión, año, supuestos_json, responsable | supuestos versionados |
| `proyeccion_linea` | escenario_id, mes, cuenta_id, importe, tipo_saldo | identificar origen y período |
| `reporte` | tipo, periodo, escenario, formato, usuario, generado_en | trazabilidad |
| `auditoria` | usuario, entidad, id_objeto, acción, fecha, antes, después | inmutable para usuarios comunes |

**Tipos:** importes `DECIMAL(14,2)` o mayor si el análisis lo justifica; cálculos con `Decimal`, no `float`. Fechas `DATE`/`TIMESTAMPTZ`. Restricciones `CHECK(debe >= 0 AND haber >= 0)` y, para detalle, prohibir que ambos sean positivos simultáneamente. El asiento completo se valida a nivel servicio antes de pasar a `contabilizado`.

### Relaciones

```mermaid
 erDiagram
  USUARIO ||--o{ LOTE_IMPORTACION : carga
  USUARIO ||--o{ AUDITORIA : ejecuta
  PERIODO ||--o{ ASIENTO : contiene
  LOTE_IMPORTACION o|--o{ ASIENTO : agrupa
  ASIENTO ||--|{ DETALLE_ASIENTO : contiene
  CUENTA ||--o{ DETALLE_ASIENTO : recibe
  CUENTA o|--o{ CUENTA : padre
  PRESUPUESTO ||--|{ PRESUPUESTO_LINEA : contiene
  CUENTA ||--o{ PRESUPUESTO_LINEA : asigna
  ESCENARIO ||--o{ PROYECCION_LINEA : genera
  CUENTA ||--o{ PROYECCION_LINEA : proyecta
```

**Nota:** el diagrama es lógico; Django User y sus grupos/permisos se apoyan en tablas internas del framework.

## 4. Catálogo de cuentas: clasificación y jerarquía

Se conservarán seis **clases principales**: 1 Activo, 2 Pasivo, 3 Patrimonio, 4 Ingresos, 5 Costos, 6 Gastos. **Seis clases no significan seis cuentas**: cada clase se desglosa en grupos, subgrupos y cuentas de movimiento.

| Código ejemplo | Cuenta | Naturaleza habitual | Estado |
|---|---|---|---|
| 1.1 | Activo corriente | Deudora | Balance |
| 1.1.01 | Caja general | Deudora | Balance |
| 1.1.02 | Bancos | Deudora | Balance |
| 1.1.03 | Cuentas por cobrar clientes | Deudora | Balance |
| 1.1.04 | Inventario de materias primas | Deudora | Balance |
| 1.1.05 | Inventario de producto terminado | Deudora | Balance |
| 1.2 | Activo no corriente | Deudora | Balance |
| 1.2.01 | Maquinaria y equipo de panadería | Deudora | Balance |
| 1.2.02 | Depreciación acumulada | Acreedora, contraactivo | Balance |
| 2.1 | Pasivo corriente | Acreedora | Balance |
| 2.1.01 | Proveedores | Acreedora | Balance |
| 2.1.02 | Obligaciones por pagar | Acreedora | Balance |
| 2.2 | Pasivo no corriente | Acreedora | Balance |
| 2.2.01 | Préstamos a largo plazo | Acreedora | Balance |
| 3.1 | Patrimonio | Acreedora | Balance y patrimonio |
| 3.1.01 | Capital aportado | Acreedora | Balance y patrimonio |
| 3.1.02 | Resultados acumulados | Acreedora habitual | Balance y patrimonio |
| 3.1.03 | Resultado del ejercicio | Variable | Balance y patrimonio |
| 4.1 | Ingresos ordinarios | Acreedora | Resultados |
| 4.1.01 | Ventas de productos de panadería | Acreedora | Resultados |
| 4.1.02 | Devoluciones y descuentos sobre ventas | Deudora, contraingreso | Resultados |
| 5.1 | Costos de ventas | Deudora | Resultados |
| 5.1.01 | Materia prima consumida | Deudora | Resultados |
| 5.1.02 | Mano de obra directa | Deudora | Resultados |
| 5.1.03 | Costos indirectos de producción | Deudora | Resultados |
| 6.1 | Gastos de operación | Deudora | Resultados |
| 6.1.01 | Sueldos administrativos | Deudora | Resultados |
| 6.1.02 | Energía administrativa | Deudora | Resultados |
| 6.1.03 | Alquiler | Deudora | Resultados |
| 6.2 | Gastos financieros | Deudora | Resultados |
| 6.2.01 | Intereses | Deudora | Resultados |

Esta tabla es un **núcleo explicativo**, no la totalidad de cuentas de un catálogo final. Para el Excel maestro conviene una columna por: código, nombre, padre, clase, naturaleza, nivel, admite movimiento, estado financiero, línea de reporte, estado activo y descripción de uso. El número de cuentas debe responder a necesidades del caso, no a una meta artificial.

## 5. Registros y partida doble

**Invariantes:** cada asiento tiene al menos dos líneas; suma debe = suma haber; no se aceptan cuentas padre como destino; importes no negativos; período abierto; cuenta activa; fecha dentro del período; no duplicar archivo/asiento accidentalmente. Importar dentro de una transacción atómica; si falla una validación crítica, no dejar asientos parciales.

**Ejemplo didáctico — venta al contado $100:** Debe Caja $100 / Haber Ventas $100. **Compra a crédito de harina $80:** Debe Inventario materias primas $80 / Haber Proveedores $80. **Consumo de harina $30:** Debe Costo de materia prima $30 / Haber Inventario $30. Son ejemplos simplificados sin tratamiento tributario; no usarlos como guía fiscal.

**Flujo de estados:** borrador → validado → contabilizado → anulado por reversión, conservando historial. Un asiento contabilizado no se elimina físicamente sin trazabilidad.

## 6. Consultas y cálculos históricos

1. Saldos iniciales por cuenta, debidamente conciliados.
2. Movimiento del período = débitos y créditos agrupados por cuenta.
3. Saldo final = saldo inicial ± movimiento según naturaleza.
4. Agregar saldos de cuentas hoja a grupos padres sin duplicar movimientos.
5. Construir estado de resultados según mapeo de cuentas a líneas.
6. Construir balance según saldos de activo/pasivo/patrimonio y resultado.
7. Construir cambios en patrimonio a partir de movimientos de capital, utilidades y retiros.

**Control 1:** total debe = total haber. **Control 2:** activo − pasivo − patrimonio = 0. **Control 3:** resultado del período del estado de resultados coincide con el usado en patrimonio. **Control 4:** saldo final de patrimonio coincide con balance.

## 7. Presupuesto

Un presupuesto tiene año, versión, estado `borrador/en_revision/aprobado`, autor y fecha. Cada línea vincula mes y cuenta presupuestable. **Ventas presupuestadas = unidades estimadas × precio**, cuando haya desglose de unidades; también se puede capturar monto directo con justificación. **Costo presupuestado = ventas × proporción de costo** o sumatoria de insumos, si hay datos. Gastos pueden presupuestarse como fijo mensual o porcentaje variable. No es necesario construir módulo operativo de producción.

**Variación absoluta = real − presupuesto**. **Variación porcentual = (real − presupuesto) / presupuesto**, cuando presupuesto distinto de cero. La interpretación favorable/desfavorable depende de si es ingreso o costo/gasto: no colorear automáticamente todo valor positivo como favorable.

## 8. Pronósticos y escenarios

Variables mínimas: crecimiento de ventas, costo/ventas, crecimiento de gastos, días de cobro, días de pago, inventario objetivo, inversiones, depreciación, aportes, retiros, deuda y pagos. Guardar supuestos por versión. La estimación puede combinar estacionalidad histórica y tasas manuales; evitar afirmar que es un modelo estadístico sofisticado si solo aplica porcentajes.

**Ejemplo de fórmulas:** `Ventas_2027_mes = Ventas_base_mes × (1 + tasa_crecimiento)`; `Costo_ventas = Ventas_proyectadas × ratio_costo`; `CxC_final ≈ Ventas_credito × días_cobro / días_periodo` (aproximación documentada); `CxP_final ≈ Compras_credito × días_pago / días_periodo`; `Inventario_final = inventario_inicial + compras − consumo`; `Efectivo_final = efectivo_inicial + cobros + financiación + aportes − pagos − inversiones − retiros`.

## 9. Estados proyectados: conciliación obligatoria

**Resultados proyectados:** calcular ventas, costos, gastos, intereses e impuesto según supuestos válidos. **Patrimonio proyectado:** patrimonio inicial + aportes + utilidad − retiros. **Balance proyectado:** partir de saldos de apertura y proyectar cada rubro mediante movimientos; si activo ≠ pasivo + patrimonio, mostrar diferencia y bloquear «aprobado/exportación final». No usar una cuenta ficticia «ajuste para cuadrar» sin explicación.

**Cédulas auxiliares necesarias:** ventas y cobros, compras y pagos, inventario, activos fijos/depreciación, préstamos/intereses/amortización, capital y retiros, efectivo. Son cálculos internos; no implican módulos autónomos adicionales.

## 10. Indicadores y presentación

- Razón corriente = activo corriente / pasivo corriente (si denominador > 0).
- Endeudamiento = pasivo total / activo total (si activo > 0).
- Margen bruto = utilidad bruta / ventas netas (si ventas > 0).
- Margen neto = utilidad neta / ventas netas (si ventas > 0).
- Variación interanual por concepto y período comparable.

Mostrar definiciones, período, unidad, fórmula y tratamiento de divisiones por cero. Para 2026 comparar enero–octubre con enero–octubre 2025, no con 2025 completo.

## 11. Endpoints y rutas Django propuestas

| Ruta | Método | Acción |
|---|---|---|
| `/login/` | GET/POST | Autenticación |
| `/usuarios/` | GET/POST | Listado y alta |
| `/usuarios/<id>/` | GET/POST | Edición |
| `/permisos/` | GET | Matriz |
| `/catalogo/` | GET | Árbol de cuentas |
| `/catalogo/cuenta/nueva/` | GET/POST | Formulario |
| `/periodos/` | GET/POST | Gestión |
| `/importaciones/` | GET/POST | Carga de Excel |
| `/importaciones/<id>/validacion/` | GET/POST | Vista previa/aprobación |
| `/asientos/` | GET | Diario |
| `/asientos/<id>/` | GET/POST | Detalle |
| `/estados/historicos/<tipo>/` | GET | Tres estados |
| `/presupuestos/` | GET/POST | Presupuesto |
| `/presupuestos/<id>/` | GET/POST | Líneas |
| `/escenarios/` | GET/POST | Escenarios |
| `/escenarios/<id>/` | GET/POST | Supuestos |
| `/proyecciones/<tipo>/` | GET | Tres estados proyectados |
| `/analisis/` | GET | Dashboard |
| `/indicadores/` | GET | Ratios |
| `/reportes/` | GET/POST | Exportación |

Las rutas son una propuesta; los nombres reales se fijarán en `urls.py`. Evitar API REST adicional si no es necesaria para el MVP.

## 12. Servicios y responsabilidades

`ValidadorImportacion`: esquema, tipos, cuentas, fechas, duplicados. `ServicioAsientos`: reglas de partida doble, persistencia atómica y reversión. `ServicioSaldos`: mayor y balanza. `ServicioEstadosHistoricos`: tres estados y conciliaciones. `ServicioPresupuesto`: versiones y variaciones. `ServicioPronosticos`: supuestos y escenarios. `ServicioProyeccion`: cédulas y tres estados futuros. `ServicioIndicadores`: ratios. `ServicioExportacion`: PDF/Excel con metadatos. `ServicioAuditoria`: registro de cambios.

## 13. Matriz de permisos

| Acción | Administrador | Analista | Gerencia |
|---|---|---|---|
| Gestionar usuarios | Sí | No | No |
| Gestionar catálogo/períodos | Sí | Lectura | Lectura |
| Preparar importaciones/asientos | Sí | Sí | No |
| Aprobar asientos/importaciones | Sí | No | No |
| Ver/exportar estados | Sí | Sí | Sí |
| Editar presupuesto | Sí | Sí | No |
| Aprobar presupuesto | Sí | No | No |
| Editar escenarios | Sí | Sí | No |
| Consultar escenarios | Sí | Sí | Sí |
| Ver auditoría | Sí | No | No |

## 14. Seguridad, calidad y operación

CSRF activo, contraseñas gestionadas por Django, sesiones seguras, validación del lado servidor, restricciones de archivos y tamaño, control de permisos en cada vista, logs sin credenciales, respaldo de PostgreSQL y pruebas automatizadas. En exportaciones incluir fecha, período, versión, usuario y leyenda de simulación. Evitar exponer archivos de importación por URL pública.

**Pruebas mínimas:** partida desbalanceada rechazada; período cerrado bloqueado; cuenta padre rechazada; Excel con código desconocido informa fila; importación duplicada controlada; estado de resultados coincide con mayor; balance cuadrado; patrimonio conciliado; escenario cambia cifras; escenario con balance descuadrado no se aprueba; usuario gerencia no edita; exportación reproduce cifras filtradas.

## 15. Plan de trabajo

**Semana 1:** configuración Django/PostgreSQL, autenticación, modelos, migraciones, catálogo y períodos. **Semana 2:** Excel, asientos, saldos y estados históricos. **Semana 3:** presupuesto, escenarios, gráficos. **Semana 4:** estados proyectados, pruebas, exportación, documentación y defensa. Realizar integración diaria y un cierre funcional al final de cada semana.

## 16. Definición de terminado

Una funcionalidad se considera terminada cuando tiene formulario/vista, permiso servidor, validaciones, persistencia, prueba básica, mensajes de error, navegación, datos simulados rotulados y evidencia capturable. Un estado financiero requiere adicionalmente fórmula y conciliación independientes.

## 17. Límites y decisiones pendientes

Definir régimen contable pertinente y normativa local aplicable con fuentes oficiales; confirmar saldos de apertura; precisar tratamiento tributario de la simulación; definir si la estimación puente de 2026 se generará o se facilitará un cierre simulado aparte; acordar qué presupuestos requieren aprobación; fijar formato definitivo del catálogo Excel. No resolver estas decisiones silenciosamente en el código.
