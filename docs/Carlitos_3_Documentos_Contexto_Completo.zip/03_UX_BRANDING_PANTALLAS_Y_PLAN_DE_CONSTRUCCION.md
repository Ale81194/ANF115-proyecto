# Panadería Carlitos — Experiencia de usuario, branding y catálogo completo de pantallas

**Producto:** Sistema de Estados Financieros, Presupuestos y Pronósticos. **Estilo visual:** panadería artesanal moderna, cálido, profesional y financiero. **Referencia:** imagen de panel de panadería aportada por la usuaria y mockups del documento técnico. **Alcance:** ocho módulos, **28 pantallas de referencia**.

## 1. Identidad y principios

El sistema se llamará visualmente **«Panadería Carlitos | Finanzas»**. Evitar el nombre de otra panadería en textos, imágenes o código final. Se buscará una interfaz acogedora y elegante sin sacrificar legibilidad financiera: fondo crema, navegación café oscuro, acciones terracota, acentos dorados, verde para resultados favorables y rojo para advertencias. La aplicación no debe parecer una tienda online: se centra en finanzas.

**Principios:** jerarquía visual clara; importes alineados a la derecha; tablas legibles; filtros visibles; confirmaciones antes de operaciones irreversibles; estados vacíos; errores explicativos; accesibilidad; consistencia de botones y formularios; datos simulados señalizados.

## 2. Paleta de marca propuesta

| Token | HEX | Uso |
|---|---|---|
| `--cafe-oscuro` | `#321B13` | Menú, encabezados, textos de alto contraste |
| `--terracota` | `#A84D2B` | Acción principal y selección |
| `--dorado` | `#D5A66C` | Detalles, ilustraciones |
| `--crema` | `#FAF3E9` | Fondo general |
| `--blanco` | `#FFFFFF` | Tarjetas y formularios |
| `--verde` | `#28785A` | Éxito y cifras favorables cuando corresponda |
| `--rojo` | `#B64232` | Error o desviación desfavorable |
| `--texto` | `#2C211D` | Texto principal |
| `--gris` | `#6F6965` | Texto secundario |
| `--borde` | `#E5D9CD` | Bordes y divisores |

**Tipografía sugerida:** títulos con serif elegante de licencia compatible, interfaz y tablas con sans-serif legible. No incrustar tipografías de terceros sin revisar licencia. Formato numérico: `$ 1,234.56`, negativos `($ 123.45)` o `−$ 123.45` de forma consistente; mostrar fecha y período.

## 3. Estructura de navegación

Navegación principal: **Inicio**, **Catálogo y períodos**, **Importaciones y asientos**, **Estados históricos**, **Presupuestos**, **Pronósticos**, **Estados proyectados**, **Análisis y reportes**. Gestión de usuarios y permisos en menú de cuenta/administración según rol. Se puede usar barra lateral colapsable inspirada en la referencia, con cabecera superior para búsqueda, período y usuario; evitar que el menú invada el área de tablas.

**Layout estándar:** logo y nombre; breadcrumb; título y descripción; selector de período/escenario; acciones; contenido principal; mensajes; leyenda «Prototipo académico — Datos simulados»; pie con fecha/versión. En pantallas pequeñas, tablas con scroll horizontal y filtros colapsables.

## 4. Inventario de 28 pantallas y especificación de cada vista

Las siguientes pantallas cubren las fichas del documento técnico. El **cierre de período** se incorpora como vista adicional de diseño por ser una función de control descrita en el módulo 2. No se agregan módulos de ventas, compras o inventario operativo.

### Módulo 1 — Autenticación, usuarios y roles

**01. Inicio de sesión**
- **Objetivo:** permitir acceso según credenciales.
- **Visual:** fotografía o ilustración de panes en un lado, tarjeta clara de formulario en otro.
- **Campos:** usuario, contraseña, recordar sesión opcional.
- **Acciones:** iniciar sesión, mostrar/ocultar contraseña.
- **Estados:** error de credenciales, cuenta inactiva, carga, éxito.
- **Roles:** público antes de iniciar sesión.
- **Regla:** no revelar si un nombre de usuario existe; nunca mostrar contraseña real en el mockup.

**02. Listado de usuarios**
- **Visual:** tabla con nombre, usuario, correo, rol, estado, acciones.
- **Filtros:** nombre, rol, activo/inactivo.
- **Acciones:** crear, editar, activar/desactivar; no eliminar registros con historial sensible.
- **Permiso:** administrador.

**03. Crear/editar usuario**
- **Campos:** nombre, identificador, correo, rol, estado; contraseña inicial solo al crear o restablecer.
- **Validaciones:** usuario/correo únicos, rol permitido, contraseñas robustas.
- **Acciones:** guardar, cancelar, restablecer contraseña según permiso.

**04. Matriz de permisos**
- **Visual:** filas de acciones/módulos y columnas Administrador/Analista/Gerencia.
- **Acciones:** ver; edición solo si se implementa permisos configurables. Para un mes, es suficiente matriz informativa basada en grupos Django.
- **Regla:** la matriz debe reflejar permisos reales de backend.

### Módulo 2 — Catálogo y períodos

**05. Árbol de cuentas**
- **Visual:** jerarquía expandible con seis clases, subgrupos y cuentas de movimiento.
- **Columnas:** código, cuenta, clase, naturaleza, nivel, admite movimientos, estado.
- **Filtros:** texto, clase, estado, naturaleza.
- **Acciones:** expandir, ver ficha, nueva cuenta según permiso.
- **Regla:** no permitir asientos sobre cuentas agrupadoras.

**06. Ficha de cuenta**
- **Campos:** código, nombre, padre, naturaleza, clase, nivel derivado, admite movimiento, activa, línea de estado financiero, descripción.
- **Validaciones:** código único; no crear ciclos padre-hijo; naturaleza coherente; no desactivar cuenta con restricciones pendientes.
- **Acciones:** guardar, cancelar.

**07. Períodos contables**
- **Visual:** tabla año, mes, inicio, fin, estado, fecha de cierre.
- **Acciones:** crear período, consultar, seleccionar, iniciar cierre.
- **Regla:** evitar períodos superpuestos y duplicados.

**08. Cierre/reapertura de período**
- **Visual:** resumen de período, checklist de validaciones, alertas de asientos pendientes, campo motivo.
- **Acciones:** cerrar, cancelar, reabrir con permiso y auditoría.
- **Regla:** bloqueo de modificación una vez cerrado.

### Módulo 3 — Importación y registros

**09. Importación de Excel**
- **Visual:** pasos 1 archivo → 2 validar → 3 confirmar → 4 importar.
- **Campos:** archivo, período, tipo de lote.
- **Ayudas:** enlace a plantilla y formato de columnas.
- **Reglas:** tamaño/extensión permitidos, hash, cuentas válidas.

**10. Validación/previsualización**
- **Visual:** tabla de filas con fecha, asiento, cuenta, debe, haber, resultado.
- **Acciones:** descargar errores, corregir archivo, confirmar importación.
- **Mensajes:** fila específica, código de error, motivo; mostrar sumas por asiento.
- **Regla:** no confirmar lotes con errores críticos.

**11. Libro diario / listado de asientos**
- **Visual:** tabla fecha, número, descripción, total, estado, usuario.
- **Filtros:** fecha, período, estado, número.
- **Acciones:** ver detalle, nuevo asiento, exportar según rol.

**12. Detalle/edición de asiento**
- **Visual:** cabecera con fecha, período, referencia, concepto; tabla dinámica de cuentas y debe/haber.
- **Acciones:** añadir línea, eliminar línea de borrador, guardar, enviar a aprobación, revertir según rol.
- **Validaciones:** dos líneas mínimas, igualdad de totales, cuentas de movimiento, período abierto.

### Módulo 4 — Estados financieros históricos

**13. Selector de período y tipo de estado**
- **Visual:** filtros año, mes/rango, acumulado, comparativo; tarjetas de tres estados.
- **Acciones:** consultar, exportar, ver detalle de cuentas.
- **Regla:** advertir que 2026 solo tiene datos históricos hasta octubre.

**14. Estado de resultados histórico**
- **Visual:** tabla jerárquica de ingresos, costo de ventas, utilidad bruta, gastos, utilidad neta.
- **Filtros:** mes, año, acumulado, comparación interanual.
- **Acciones:** desplegar cuentas, exportar PDF/Excel.
- **Regla:** resultados calculados desde mayor; mostrar período exacto.

**15. Balance general histórico**
- **Visual:** dos columnas de activo y pasivo+patrimonio; totales y comprobación.
- **Filtros:** fecha de corte.
- **Estados:** «Balance conciliado» o «Diferencia detectada: $X».
- **Regla:** activos = pasivos + patrimonio.

**16. Cambios en patrimonio histórico**
- **Visual:** tabla patrimonio inicial, aportes, utilidad, retiros y patrimonio final.
- **Acciones:** desglose y exportación.
- **Regla:** patrimonio final coincide con balance.

### Módulo 5 — Presupuestos

**17. Presupuesto anual/mensual**
- **Visual:** año y versión; tabla de meses, ventas, costos, gastos, utilidad prevista; totales.
- **Estados:** borrador, revisión, aprobado.
- **Acciones:** nuevo presupuesto, duplicar versión, editar, aprobar según rol.

**18. Editor de líneas presupuestarias**
- **Visual:** formulario por cuenta y mes; campo importe, método y observación.
- **Acciones:** añadir, guardar borrador, validar.
- **Reglas:** cuentas habilitadas y presupuesto no aprobado para edición.

**19. Comparativo presupuesto vs real**
- **Visual:** tabla concepto, presupuesto, real, diferencia, porcentaje; gráfico comparativo.
- **Filtros:** período comparable.
- **Regla:** cuando no exista real, mostrar «No disponible»; no usar ceros ficticios.

### Módulo 6 — Pronósticos y escenarios

**20. Listado de escenarios**
- **Visual:** tarjetas base, optimista y pesimista; año, versión, autor, fecha.
- **Acciones:** crear versión, seleccionar, duplicar, consultar.

**21. Editor de supuestos**
- **Campos:** crecimiento ventas, porcentaje costo, gastos, días de cobro/pago, inventario, inversiones, deuda, aportes, retiros.
- **Ayudas:** unidad, rango, explicación y efecto esperado de cada variable.
- **Acciones:** guardar supuestos, calcular pronóstico, restaurar versión.
- **Regla:** registrar cambios y no sobrescribir versiones aprobadas.

**22. Comparación de escenarios**
- **Visual:** líneas/barras para ventas, utilidad, liquidez y patrimonio; tabla base/optimista/pesimista.
- **Acciones:** alternar indicador, descargar resumen.
- **Regla:** mismo período y mismo criterio de comparación.

### Módulo 7 — Estados financieros proyectados

**23. Estado de resultados proyectado**
- **Visual:** tabla mensual y anual, selector escenario y versión, columna comparativa histórica.
- **Acciones:** recalcular, exportar si validado.
- **Regla:** separar cifras estimadas de cifras históricas.

**24. Balance general proyectado**
- **Visual:** activo/pasivo/patrimonio, fecha de cierre, indicador de conciliación y enlaces a cédulas auxiliares.
- **Acciones:** ver movimientos de caja, CxC, inventario, CxP y deuda; exportar cuando cuadre.
- **Regla:** diferencia ≠ 0 bloquea aprobación final.

**25. Cambios en patrimonio proyectado**
- **Visual:** saldo inicial, aportes, utilidad proyectada, retiros, saldo final.
- **Acciones:** ver supuestos y exportar.
- **Regla:** saldo final coincide con balance proyectado.

### Módulo 8 — Análisis y reportes

**26. Panel ejecutivo (dashboard)**
- **Visual:** tarjetas ventas, costo, gastos, utilidad; gráfico histórico; alertas de conciliación; accesos rápidos.
- **Filtros:** año/mes y tipo histórico/proyectado.
- **Regla:** evitar comparar 10 meses de 2026 con 12 meses de 2025.

**27. Indicadores financieros**
- **Visual:** razón corriente, endeudamiento, margen bruto, margen neto; tendencias y definiciones.
- **Acciones:** ver fórmula y componentes, exportar.
- **Regla:** división por cero → «No calculable», no infinito.

**28. Generación/exportación de reportes**
- **Visual:** selector tipo, período, escenario, versión, formato PDF/Excel, vista previa.
- **Acciones:** generar y descargar.
- **Reglas:** exportación solo con permisos; estados proyectados aprobados y conciliados; incluir metadatos y leyenda de simulación.

## 5. Componentes reutilizables

`AppShell` (menú + cabecera), `PageHeader`, `PeriodFilter`, `ScenarioSelector`, `DataTable`, `AccountTree`, `MoneyCell`, `StatusBadge`, `SummaryCard`, `ChartCard`, `FormField`, `ConfirmDialog`, `ValidationSummary`, `EmptyState`, `ErrorState`, `ExportDialog`, `AuditStamp`. El diseño de estos componentes primero reduce mucho el trabajo de 28 pantallas.

## 6. Estados de interacción transversales

- **Cargando:** esqueleto o indicador con texto, sin cifras engañosas.
- **Vacío:** «No hay asientos en el período seleccionado» + acción contextual.
- **Error:** explicar qué falló, dónde y cómo corregirlo.
- **Éxito:** confirmación no invasiva.
- **Sin permiso:** mensaje 403 claro, sin mostrar datos sensibles.
- **Datos no conciliados:** bloqueo de aprobación/exportación final, con diferencia visible.
- **Datos simulados:** aviso persistente en pantallas y reportes.

## 7. Guía de diseño responsivo

**Escritorio (≥1200 px):** menú lateral, contenido de dos columnas cuando corresponda, tablas completas. **Tableta:** menú colapsable, filtros en segunda línea. **Móvil:** tarjetas en columna, tablas con desplazamiento horizontal y acciones agrupadas. Priorizar uso en computadora para tareas contables extensas.

## 8. Accesibilidad y usabilidad

Etiquetas asociadas a campos; navegación por teclado; contraste suficiente; no depender solo de colores para estados; mensajes vinculados a entradas inválidas; botones con nombres claros; confirmación antes de cierre; no usar únicamente iconos ambiguos; valores numéricos con unidad y signo; fechas consistentes.

## 9. Ejemplo de tokens CSS

```css
:root {
  --cafe-oscuro: #321B13;
  --terracota: #A84D2B;
  --dorado: #D5A66C;
  --crema: #FAF3E9;
  --verde: #28785A;
  --rojo: #B64232;
  --texto: #2C211D;
  --borde: #E5D9CD;
  --radio: 14px;
  --sombra: 0 6px 22px rgba(50,27,19,.09);
}
body { background: var(--crema); color: var(--texto); }
.btn-primary { background: var(--terracota); color: #fff; border-radius: 10px; }
.card { background: #fff; border: 1px solid var(--borde); border-radius: var(--radio); box-shadow: var(--sombra); }
.money { font-variant-numeric: tabular-nums; text-align: right; }
```

## 10. Plantilla HTML mínima (referencia visual, no funcional)

```html
<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Carlitos | Finanzas</title></head>
<body>
  <aside aria-label="Navegación principal"><strong>Panadería Carlitos</strong><nav><a href="/analisis/">Inicio</a><a href="/catalogo/">Catálogo</a><a href="/estados/historicos/resultados/">Estados históricos</a><a href="/presupuestos/">Presupuestos</a><a href="/escenarios/">Pronósticos</a></nav></aside>
  <main><header><h1>Panel financiero</h1><p>Prototipo académico — Datos simulados</p></header><section aria-label="Resumen"><article class="card"><h2>Ventas del período</h2><p class="money">—</p></article></section></main>
</body>
</html>
```

El guion `—` evita inventar cifras en una plantilla. En Django los valores provendrán de servicios de dominio.

## 11. Plan de producción de pantallas

**Día 1–3:** sistema de diseño, navegación, login, componentes comunes. **Día 4–7:** catálogo, períodos, importación y diario. **Semana 2:** tres estados históricos, tablas y exportación básica. **Semana 3:** presupuesto, escenarios, indicadores. **Semana 4:** estados proyectados, pruebas de flujos, ajustes responsive, evidencias y video.

El desarrollo no exige construir 28 diseños independientes desde cero: se reutilizan layouts, tablas y formularios. Priorizar primero **funcionalidad y conciliación**, luego acabado visual.

## 12. Reglas para producir mockups imagen por imagen

Cada pantalla debe entregarse como imagen independiente, nombre `M01_P01_Login.png` ... `M08_P28_Exportacion.png`, idealmente 1440×900 o 1600×1000; mantener logo, paleta, barra lateral y tipografía; mostrar datos de demostración coherentes; no mezclar períodos; evitar cifras inventadas que no cuadren en estados; incluir título y acciones específicas; no añadir módulos no previstos. **Una lámina collage no sustituye 28 archivos individuales**.

Para generar mockups, partir de este documento y del técnico. Se puede producir una ficha por pantalla con: objetivo, rol, datos, componentes, acciones, validaciones y estados; después generar la imagen y revisar ortografía y coherencia. Las imágenes son **conceptuales**, no capturas del software implementado.

## 13. Guion de demostración del proyecto

1. Ingresar como analista; mostrar permisos.
2. Abrir catálogo y explicar seis clases y subcuentas.
3. Importar un Excel simulado y revisar errores.
4. Mostrar un asiento y la balanza.
5. Generar estado de resultados, balance y cambios en patrimonio históricos.
6. Elaborar presupuesto 2027 y explicar supuestos.
7. Comparar escenarios.
8. Generar resultados, balance y patrimonio proyectados conciliados.
9. Consultar indicadores y exportar.
10. Entrar como gerencia y demostrar acceso de solo lectura.

## 14. Lista de verificación antes de aceptar una pantalla

- Título y módulo correctos.
- Fecha, período y escenario visibles donde corresponda.
- Acciones coherentes con rol.
- Estado vacío y error diseñados.
- Montos y totales coherentes.
- Filtros aplicados de verdad en backend.
- Datos simulados rotulados.
- Diseño accesible y usable.
- La captura coincide con la versión implementada.

## 15. Estado de este documento

Es una **guía integral de UX, branding y pantallas** basada en el alcance técnico, no una entrega de 28 imágenes ni de HTML funcional. Sirve como contrato de diseño para generar mockups y construir plantillas Django sin perder consistencia entre módulos.
