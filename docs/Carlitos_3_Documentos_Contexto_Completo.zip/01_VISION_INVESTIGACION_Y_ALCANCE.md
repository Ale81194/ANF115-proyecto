# Panadería Carlitos — Visión, investigación y alcance

**Proyecto:** Sistema de Estados Financieros, Presupuestos y Pronósticos.  
**Contexto:** Universidad de El Salvador, Facultad de Ingeniería y Arquitectura, Educación a Distancia.  
**Equipo:** tres integrantes. **Plazo:** cuatro semanas. **Fecha de referencia:** octubre de 2026.  
**Advertencia:** caso académico con cifras financieras **simuladas**; no son registros reales de Panadería Carlitos.

## 1. Idea central

Se construirá una aplicación web para organizar información contable, verificar su integridad, emitir estados financieros históricos, preparar presupuestos y pronósticos y elaborar estados financieros proyectados. Se busca facilitar decisiones sobre rentabilidad, liquidez, endeudamiento y uso de recursos. El producto es un **subsistema financiero especializado**, no un ERP ni una plataforma de facturación, producción, compras, inventario operativo o planillas.

La empresa de referencia es Panadería Carlitos, ubicada en Chalatenango, El Salvador. La caracterización comercial, antecedentes y procesos actuales deben sustentarse con investigación verificable; **no debe afirmarse que la empresa utiliza o necesita actualmente un procedimiento concreto sin evidencia**. Las cifras usadas en la aplicación se rotularán «Datos simulados para fines académicos».

## 2. Planteamiento del problema

Una organización que administra datos contables dispersos puede encontrar dificultades para consolidar saldos, comparar períodos y anticipar necesidades financieras. El sistema propuesto aborda ese problema mediante una secuencia trazable: **catálogo → asientos → libro mayor y balanza → estados históricos → presupuestos → pronósticos → estados proyectados → indicadores y reportes**.

Esto es una **hipótesis de solución** para el caso académico, no un diagnóstico empírico confirmado de Panadería Carlitos. La investigación preliminar deberá identificar fuentes de información, usuarios y necesidades de decisión.

## 3. Objetivos

**General:** diseñar e implementar un subsistema web de información financiera que procese datos contables de prueba y permita generar estados históricos, presupuestos, pronósticos y estados proyectados con controles de consistencia.

**Específicos:** (1) investigar necesidades y marco normativo; (2) diseñar catálogo y esquema relacional; (3) validar importaciones y partida doble; (4) generar tres estados históricos; (5) presupuestar ventas, costos y gastos; (6) estimar escenarios de 2027; (7) emitir tres estados proyectados conciliados; (8) producir indicadores y reportes exportables; (9) demostrar permisos y pruebas.

## 4. Alcance temporal

| Intervalo | Clasificación | Regla |
|---|---|---|
| Enero–diciembre 2024 | Histórico simulado | 12 meses |
| Enero–diciembre 2025 | Histórico simulado | 12 meses |
| Enero–octubre 2026 | Histórico simulado | 10 meses |
| Noviembre–diciembre 2026 | Solo estimación puente, si se requiere | Nunca presentar como histórico |
| Enero–diciembre 2027 | Presupuesto y proyección | Escenarios diferenciados |

**Advertencia técnica:** para proyectar el balance de 2027 se requiere un saldo de apertura. Si la base histórica termina en octubre de 2026, debe construirse y etiquetarse una estimación puente hasta diciembre o partir de un cierre 2026 validado posteriormente. Sin esta condición no se puede afirmar que el balance proyectado sea completo.

## 5. Ocho módulos definitivos

| N.º | Módulo | Responsabilidad |
|---|---|---|
| 1 | Autenticación, usuarios y roles | Inicio de sesión, perfiles, matriz de permisos |
| 2 | Catálogo y períodos | Jerarquía de cuentas, períodos y cierre |
| 3 | Importación y registros | Excel, prevalidación, asientos, diario |
| 4 | Estados históricos | Resultados, situación financiera y patrimonio |
| 5 | Presupuestos | Ventas, costos, gastos, edición y comparativos |
| 6 | Pronósticos y escenarios | Supuestos, escenarios base/optimista/pesimista |
| 7 | Estados proyectados | Resultados, balance y patrimonio para 2027 |
| 8 | Análisis y reportes | Dashboard, indicadores, PDF y Excel |

El dashboard forma parte del módulo 8; **no es un noveno módulo**.

## 6. Seis estados financieros comprometidos

### 6.1 Históricos

1. **Estado de resultados:** ventas netas − costo de ventas = utilidad bruta; menos gastos operativos y otras partidas pertinentes = resultado antes de impuestos; menos impuesto determinado bajo supuestos explícitos = utilidad neta. Se emite mensual y acumulado.
2. **Estado de situación financiera (balance general):** activos corrientes/no corrientes, pasivos corrientes/no corrientes y patrimonio, con comprobación **Activo = Pasivo + Patrimonio**. Se emite a fecha de corte.
3. **Estado de cambios en el patrimonio:** patrimonio inicial + aportaciones + resultado del período − retiros/distribuciones ± ajustes sustentados = patrimonio final.

### 6.2 Proyectados para 2027

4. **Estado de resultados proyectado:** ingresos, costos, gastos y utilidad mensual/anual calculados por escenario.
5. **Estado de situación financiera proyectado:** activos, pasivos y patrimonio calculados a partir de saldos de apertura y movimientos estimados. Se exige balance cuadrado; no basta multiplicar todas las cuentas por una tasa.
6. **Estado de cambios en el patrimonio proyectado:** capital y reservas iniciales + aportes + utilidad proyectada − retiros = patrimonio de cierre.

### 6.3 Fuera del MVP

Estado formal de flujos de efectivo, inventario PEPS transaccional, planillas AFP/ISSS, punto de venta, facturación, producción y compras. **Sí** se necesita una cédula auxiliar de caja/cobros/pagos para que el balance proyectado sea consistente; esa cédula no se anunciará como un estado formal de flujos de efectivo.

## 7. Presupuestos, pronósticos y escenarios: conceptos distintos

- **Presupuesto:** metas mensuales aprobadas para ventas, costos y gastos; admite versión, responsable y estado.
- **Pronóstico:** estimación revisable basada en tendencia histórica y supuestos.
- **Proyección:** resultado de trasladar supuestos a estados financieros futuros.
- **Escenario:** combinación identificable de variables, por ejemplo crecimiento de ventas, porcentaje de costos, inflación de gastos, días de cobro y pago, inversiones y retiros.

Escenarios mínimos: **base, optimista y pesimista**. Un comparativo «real versus presupuesto 2027» debe indicar que los reales no están disponibles hasta que existan; no inventarlos.

## 8. Roles

**Administrador:** CRUD de usuarios y catálogo, apertura/cierre de períodos, aprobación de importaciones y presupuestos, lectura/exportación, auditoría.  
**Analista contable:** preparar asientos e importaciones, editar presupuestos y supuestos, consultar/exportar estados; sin administración de usuarios ni aprobación de sus propias operaciones.  
**Gerencia:** consulta de estados, indicadores, escenarios, presupuestos y reportes; sin edición contable.

La seguridad se comprueba en Django, no solamente ocultando botones.

## 9. Investigación preliminar que sí debe realizarse

Documentar: giro comercial, contexto de panificación, productos generales, fuentes de ingresos y costos, actores, documentos que se usarían, decisiones que los reportes deben apoyar, necesidades y limitaciones. Separar **hechos comprobados**, **observaciones**, **entrevistas**, **supuestos** y **datos simulados**. Si no hubo entrevista, indicarlo; no fabricar testimonios.

**Preguntas sugeridas:** ¿qué datos financieros se registran?, ¿con qué periodicidad?, ¿quién los revisa?, ¿cómo se controlan costos de harina, energía y mano de obra?, ¿cómo se estima la demanda?, ¿cómo se planifican inversiones?, ¿qué indicadores se consideran útiles?

## 10. Fundamentación contable y normativa

Investigar las NIIF para las PYMES aplicables al contexto, principios de presentación y reconocimiento, partida doble, normas profesionales y obligaciones pertinentes en El Salvador. Contrastar la edición internacional de las normas con la **adopción y vigencia local**; no asumir que una edición internacional rige automáticamente en la entidad. Consultar fuentes primarias del CVPCPA, IFRS Foundation y legislación salvadoreña. **No se incluyen citas textuales inventadas.** Las citas y referencias APA 7 deben completarse con documentos efectivamente consultados.

## 11. Relación con la rúbrica

| Criterio | Peso | Evidencia |
|---|---:|---|
| Investigación y análisis | 30% | Contexto, problema, fuentes, análisis y justificación |
| Enfoque técnico | 30% | Arquitectura, base de datos, fórmulas, controles, pruebas |
| Redacción y ortografía | 10% | Edición final coherente |
| APA y estructura | 10% | Introducción, objetivos, desarrollo, glosario, conclusiones, recomendaciones y referencias |
| Videoexposición | 20% | Demostración funcional y explicación de decisiones |

**Formato:** la rúbrica original compartida indica **Arial 12, título 1 Arial 14 negrita, interlineado 1.5 y márgenes normales**. En otra solicitud se pidió Times New Roman; confirmar con el docente antes de exportar el Markdown a Word. Usar sangría y citas según APA 7.

## 12. Índice propuesto para el informe extenso

Portada; índice general; índices de tablas/figuras; resumen; introducción; problema; objetivos; justificación; delimitación; antecedentes de la panadería; marco teórico contable; estados financieros; presupuestos y pronósticos; marco normativo; metodología; instrumentos de investigación; análisis de necesidades; propuesta funcional; arquitectura; base de datos; reglas financieras; roles; prototipos; estrategia de pruebas; cronograma; resultados de implementación; conclusiones; recomendaciones; glosario; referencias APA verificadas; anexos de catálogo, diagramas, pruebas y mockups.

**Meta:** un informe final de alrededor de 50 páginas **sustantivas**, sin alargar artificialmente con texto repetido. Este `.md` es un insumo de contenido y estructura, no un informe final de 50 páginas ni evidencia de implementación.

## 13. Cronograma de cuatro semanas

**Semana 1:** autenticación, esquema PostgreSQL, catálogo, períodos, configuración y dataset de prueba.  
**Semana 2:** importación, diario, validación y tres estados históricos.  
**Semana 3:** presupuestos, pronósticos, escenarios, indicadores básicos.  
**Semana 4:** tres estados proyectados, conciliación, exportaciones, pruebas, documentación y video.

**Ruta crítica:** datos correctos → estados históricos → presupuesto/escenarios → proyección vinculada. Si hay atrasos, reducir animaciones y métricas secundarias antes que las conciliaciones.

## 14. Criterios de aceptación de alto nivel

- Los asientos no balanceados no se contabilizan.
- Las cuentas de agrupación no aceptan movimientos directos.
- Los períodos cerrados no admiten cambios sin reapertura autorizada y auditada.
- Los estados se derivan de saldos, no de importes codificados en HTML.
- Los balances histórico y proyectado cuadran a centavos.
- El patrimonio concilia con su estado de cambios.
- Se conservan versión y supuestos de cada presupuesto y escenario.
- Los datos simulados están rotulados en pantalla y exportaciones.
- Cada rol solo accede a acciones autorizadas.
- El video muestra al menos una importación, un estado histórico, un escenario y un estado proyectado.

## 15. Riesgos

**Datos incoherentes:** pruebas de mayor, balanza y ecuación contable. **Balance proyectado descuadrado:** cédulas de movimientos de efectivo y capital de trabajo. **Sobrealcance:** ocho módulos sin ERP. **Normativa desactualizada:** contrastar fuentes oficiales. **Información ficticia confundida con real:** advertencia persistente. **Tiempo limitado:** división de tareas y entregas semanales.

## 16. Glosario

**Asiento:** registro contable de una operación. **Partida doble:** igualdad de cargos y abonos. **Cuenta mayor:** cuenta que acumula movimientos. **Balanza:** sumas y saldos para comprobación. **Presupuesto:** plan financiero. **Pronóstico:** estimación revisable. **Proyección:** cálculo de estados futuros. **Escenario:** conjunto de supuestos. **Liquidez:** capacidad de cumplir obligaciones de corto plazo. **Patrimonio:** interés residual en activos tras deducir pasivos. **Trazabilidad:** posibilidad de reconstruir origen y transformación de un importe.

## 17. Estado del documento

Es una **especificación de producto e investigación**. No certifica que el software esté implementado ni que existan entrevistas o cifras empresariales reales. Debe mantenerse sincronizada con el código, la documentación técnica y la demostración final.
