# Referencias visuales históricas

Estos cinco mockups se conservan del paquete anterior de Panadería Carlitos. Algunos muestran catálogo contable, importaciones u otras funciones del diseño previo. Son referencias visuales y no definen el alcance actual.

Para construir o exponer el sistema vigente, usar los siete módulos del contexto 01 y las pantallas de Artefactos/Pantallas. No recuperar los ocho módulos anteriores a partir de estas imágenes.
