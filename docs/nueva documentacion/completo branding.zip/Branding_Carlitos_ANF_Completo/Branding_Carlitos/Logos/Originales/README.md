# Logos originales conservados

Estos cinco SVG se recuperaron sin alterar del paquete de branding anterior. Conservan su color y composición originales. Son propuestas académicas de marca.

Las variantes en la carpeta principal de Logos adaptan el símbolo de trigo a los tokens actuales y al sistema visual del ejemplo. AlternativaPan contiene una propuesta adicional de isotipo de pan; no es un segundo producto ni un módulo.
