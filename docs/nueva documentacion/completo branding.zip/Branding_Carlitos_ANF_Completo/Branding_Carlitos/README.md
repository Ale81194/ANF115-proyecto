# Panadería Carlitos — ANF

Paquete de identidad y contexto para **ANF — Análisis Financiero**. Alcance: Usuarios, Ingresos, Gastos, Categorías, Panel financiero, Reportes, Seguridad y bitácora. Tecnología conservada: React + TypeScript + Vite y Supabase/PostgreSQL.

Abrir `HTML/index.html` después de extraer todo el ZIP para explorar el ejemplo con datos ficticios. Los logos son una propuesta académica editable. Leer `Documentacion/MANUAL_IDENTIDAD.md` para aplicarlos.

## Contenido

- Assets: iconos, favicon, patrón, ilustración y categorías.
- Logos: versiones horizontal, apilada e isotipos, en SVG y PNG.
- Artefactos: brandboard, portada, pantallas ilustrativas y modelo Supabase aplicado.
- HTML: ejemplo local adaptable, siete módulos y reportes.
- Skills: reglas reutilizables de diseño y base de datos.
- Paleta: tokens CSS/JSON y paleta GPL.
- Documentacion: tres contextos completos, Word corregido a ANF, manual y licencia.

## Estado de Supabase

La migración **ya fue aplicada y verificada en Supabase**, versión `20261021041732`. Se conservaron veinte tablas, dos vistas y doce funciones anteriores en un archivo privado y se activaron cinco tablas nuevas con 12 políticas RLS y 26 categorías. El asesor de seguridad no reportó hallazgos. No volver a ejecutar el SQL incluido; consultar la evidencia remota y los tipos TypeScript en Artefactos/Supabase.

Las 52 comprobaciones SQL y las 17 del HTML son locales. Los ejemplos no autentican personas ni conectan con Supabase; no contienen claves ni contraseñas. El catálogo operativo contiene 26 categorías y el catálogo contable de referencia 47 cuentas; ambos están completos en el Word y en JSON. El catálogo contable no es un módulo adicional.

Se conservan los cinco SVG anteriores en `Logos/Originales`, una alternativa de pan en `Logos/AlternativaPan` y cinco mockups previos en `Assets/ReferenciasHistoricas`. Estos mockups no definen funciones actuales; usar `Artefactos/Pantallas` y los siete módulos del contexto vigente.
