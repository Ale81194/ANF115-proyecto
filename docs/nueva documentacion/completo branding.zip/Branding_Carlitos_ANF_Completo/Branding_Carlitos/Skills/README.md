# Skills del proyecto ANF

Incluye carlitos-brand-ui y carlitos-supabase, con SKILL.md, configuración de agente y referencias. Ambas pasaron la validación de estructura; la skill visual se comprobó con una tarea independiente de reporte sin ingresos.

Pueden reutilizarse desde esta carpeta en herramientas compatibles con skills. El guardado automático en la lista de Skills no se completó: el envío al repositorio devolvió HTTP 422. Los archivos completos se conservan aquí y no dependen de que ese guardado funcione.

La skill de base de datos documenta que la migración remota sigue pendiente y exige comprobar el estado real antes de modificarlo. No incluir claves ni sustituir las políticas del servidor por instrucciones de una skill.
