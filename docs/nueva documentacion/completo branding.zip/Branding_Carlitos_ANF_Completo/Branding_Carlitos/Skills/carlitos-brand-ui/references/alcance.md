# Contexto del proyecto Panadería Carlitos

**Asignatura:** ANF — Análisis Financiero. **Actualización:** 21 de octubre de 2026. **Estado:** base de datos migrada y verificada en Supabase; prototipo local e integración React/Auth pendientes.

Este archivo fija el alcance vigente del proyecto. Leerlo antes de programar o modificar el informe. La guía y la rúbrica gobiernan los módulos, los cálculos y la entrega. La elección tecnológica es libre, conforme a la aclaración del docente comunicada por la usuaria y al apartado 12.3 de la guía. Conservar React, TypeScript, Vite y Supabase con PostgreSQL.

## Propósito y problema

Panadería Carlitos es el caso académico de una pequeña empresa de Chalatenango. El proyecto organiza ingresos y gastos, reduce errores de registro y permite consultar resultados por período. No atribuir entrevistas, cifras reales, validaciones empresariales ni implementaciones terminadas que no estén documentadas. Los importes del prototipo son exclusivamente demostrativos.

Pregunta orientadora: ¿Cómo puede un sistema web centralizar y controlar los ingresos y gastos de Panadería Carlitos para obtener información financiera confiable por período?

Objetivo general: desarrollar un sistema web que permita registrar, clasificar y consultar ingresos y gastos y calcular resultados financieros para apoyar el control económico de Panadería Carlitos.

Objetivos específicos: analizar el registro financiero; diseñar un modelo relacional; implementar usuarios, ingresos, gastos y categorías; calcular los cuatro indicadores; generar gráficos y reportes diarios, mensuales y anuales; y verificar permisos, integridad y trazabilidad.

## Siete módulos obligatorios

| Orden | Módulo | Funciones y evidencia esperada |
|---|---|---|
| 1 | Usuarios | Iniciar/cerrar sesión; registrar cuentas mediante un flujo administrativo seguro; consultar, modificar y desactivar perfiles; asignar administrador o empleado. |
| 2 | Ingresos | Registrar concepto, monto, fecha y categoría de ingreso; consultar y modificar según permisos; anular con motivo. |
| 3 | Gastos | Registrar concepto, monto, fecha y categoría de gasto; consultar y modificar según permisos; anular con motivo. |
| 4 | Categorías | Crear, consultar, editar y desactivar categorías de ingresos o gastos; conservar la relación histórica. |
| 5 | Panel financiero | Mostrar ingresos, gastos, resultado y porcentaje de gastos con gráficos coherentes y filtros por fechas. |
| 6 | Reportes | Consultar detalle y consolidaciones diarias, mensuales y anuales; filtrar fechas y categoría; exportación como complemento. |
| 7 | Seguridad y bitácora | Aplicar permisos, sesiones y validaciones; registrar altas, modificaciones y anulaciones con actor y fecha. |

No agregar contabilidad general, presupuestos, escenarios, proyecciones, nómina, inventario, facturación electrónica, bancos ni transferencias reales como módulos. El catálogo contable completo se incorpora como referencia académica en el Word; no crea un octavo módulo ni exige tablas de asientos.

## Roles y reglas funcionales

El administrador activo consulta todos los movimientos y sus reportes, administra categorías y cuentas y consulta la bitácora. El empleado activo registra y consulta sus propios movimientos, modifica los propios vigentes y obtiene indicadores y reportes limitados a ellos. Puede consultar categorías activas y las inactivas necesarias para interpretar sus registros históricos. No puede administrar categorías ni cuentas ni consultar la bitácora administrativa. Una cuenta inactiva carece de acceso operativo incluso si mantiene un token aún válido.

Las cuentas nuevas nacen como empleado inactivo. El rol nunca se toma de metadatos editables por el usuario. Debe existir al menos un administrador activo después de configurar la primera cuenta. Los movimientos se anulan, no se borran físicamente; el motivo es obligatorio y una anulación es definitiva. La identidad del creador y la fecha de alta son inmutables.

## Indicadores y criterios de aceptación

| Indicador | Regla |
|---|---|
| Ingresos totales I | Suma de ingresos vigentes, autorizados y dentro del período inclusivo. |
| Gastos totales G | Suma de gastos vigentes con los mismos filtros. |
| Resultado financiero | I − G; admitir resultados negativos. |
| Porcentaje de gastos | G / I × 100 si I > 0; en otro caso, null en API y “No aplica” en interfaz. |

Usar USD, importes positivos con máximo dos decimales y aritmética decimal en PostgreSQL. No interpretar el resultado de movimientos como utilidad contable auditada, saldo bancario ni flujo de efectivo formal con conciliación. Una fecha financiera es `date`; los eventos de auditoría son `timestamptz`. Mostrar fechas locales sin desplazar el día del movimiento por conversiones UTC.

Caso demostrativo de octubre de 2026: cuatro ingresos de $3,000, $2,500, $3,500 y $3,000; seis gastos de $4,000, $800, $600, $200, $400 y $3,600. Resultado esperado: I=$12,000; G=$9,600; resultado=$2,400; porcentaje=80 %. Del 1 al 7 de octubre: I=$5,500; G=$4,800; resultado=$700. Un período vacío devuelve ceros y porcentaje “No aplica”. Estos datos no se cargan en la migración remota.

## Catálogo operativo completo

Las categorías siguientes son la semilla de la base objetivo y del ejemplo HTML. Código estable; nombre editable por administrador. Una categoría usada conserva su tipo y código.

| Código | Tipo | Nombre | Descripción |
|---|---|---|---|
| I01 | ingreso | Ventas de pan dulce | Cobros por pan dulce vendido. |
| I02 | ingreso | Ventas de pan francés | Cobros por pan francés vendido. |
| I03 | ingreso | Ventas de repostería | Cobros por pasteles y otros productos de repostería. |
| I04 | ingreso | Ventas de pan integral | Cobros por productos de panadería integral. |
| I05 | ingreso | Ventas de galletas | Cobros por galletas elaboradas para la venta. |
| I06 | ingreso | Pedidos especiales | Cobros por pedidos identificados como especiales; no duplicar otra venta. |
| G01 | gasto | Ingredientes | Harina, levadura, azúcar, manteca y demás ingredientes pagados. |
| G02 | gasto | Empaques | Bolsas, cajas y otros materiales de empaque pagados. |
| G03 | gasto | Gas de producción | Pagos de gas utilizado por los hornos. |
| G04 | gasto | Energía eléctrica | Pagos del suministro de electricidad. |
| G05 | gasto | Agua | Pagos del servicio de agua. |
| G06 | gasto | Alquiler | Pagos por el uso del local. |
| G07 | gasto | Pagos de personal | Pagos operativos al personal; no constituye un módulo de nómina. |
| G08 | gasto | Transporte | Pagos de entregas y transporte relacionados con la operación. |
| G09 | gasto | Suministros | Artículos operativos y de oficina distintos de ingredientes y empaques. |
| G10 | gasto | Limpieza | Productos y servicios de limpieza. |
| G11 | gasto | Mantenimiento de equipos | Reparación y mantenimiento ordinario de hornos y equipos. |
| G12 | gasto | Mantenimiento del local | Conservación ordinaria de las instalaciones. |
| G13 | gasto | Publicidad | Pagos de publicidad y promoción. |
| G14 | gasto | Telefonía e internet | Pagos de comunicaciones del negocio. |
| G15 | gasto | Comisiones de cobro | Comisiones pagadas por medios de cobro. |
| G16 | gasto | Permisos y tasas | Pagos operativos identificados por permisos o tasas. |
| G17 | gasto | Seguros | Pagos de seguros relacionados con la operación. |
| G18 | gasto | Servicios profesionales | Pagos por servicios profesionales recibidos. |
| G19 | gasto | Uniformes y protección | Pagos por uniformes e implementos de protección. |
| G20 | gasto | Otros gastos operativos | Pagos no comprendidos en otra categoría; exigir concepto específico. |

El catálogo contable de referencia contiene 47 cuentas. Su listado íntegro se conserva en `Artefactos/Supabase/catalogo_contable_referencia.json` y en el Word. El documento es autosuficiente: no depende de presentar un Excel separado.

## Arquitectura y organización de construcción

La aplicación prevista utiliza React + TypeScript y Vite para la interfaz; Supabase Auth para identidad; PostgreSQL para persistencia, restricciones, RLS y cálculos; y un servicio de administración del lado del servidor para crear cuentas de Auth. La clave privilegiada nunca se incluye en Vite, HTML ni repositorios públicos. Las cinco entidades operativas son perfiles, categorías, ingresos, gastos y bitácora. Panel y reportes consultan movimientos mediante vista y RPC con permisos del usuario.

Organizar el futuro código en `features/usuarios`, `ingresos`, `gastos`, `categorias`, `panel`, `reportes` y `seguridad`; compartir componentes de formulario, filtros, tablas, moneda y mensajes. Mantener contratos de datos y acceso separados de la presentación. El HTML del ZIP es un ejemplo funcional local, no la aplicación React ya integrada.

## Correspondencia con guía y rúbrica

| Criterio de rúbrica | Ponderación de la columna Total | Evidencia por completar o conservar |
|---|---:|---|
| Planteamiento, justificación, objetivos y alcance | 10 | Problema delimitado, pregunta, objetivos verificables y exclusiones. |
| Investigación y fundamentación | 20 | Fuentes verificables, análisis propio y citas concordantes. |
| Diseño, base de datos y arquitectura | 20 | Cinco entidades, relaciones, diccionario, políticas y pantallas de siete módulos. |
| Implementación de módulos | 10 | Demostración conectada de altas, consultas, cambios, filtros y roles. |
| Cálculos, reportes y visualización | 10 | Cuatro indicadores y reportes diario/mensual/anual verificados. |
| Seguridad, integridad y calidad técnica | 10 | Auth, RLS, validaciones, controles del servidor y procedimiento de respaldo. |
| Informe y APA 7 en español | 10 | Word profesional de 30–40 páginas; títulos, tablas, figuras y referencias coherentes. |
| Pruebas, documentación y defensa | 10 | Manual, evidencia reproducible y videoexposición de 20 minutos con tres integrantes. |

La guía presenta discrepancias entre los valores descriptivos de sus niveles y la columna de ponderaciones. Conservar las ponderaciones de la columna Total que suman 100; no prometer una calificación. La guía indica entrega el 10 de noviembre a las 23:59; comprobar cualquier actualización del docente.

## Documentación y estado real de entrega

El Word actualizado conserva tipografía, tamaños, espacios y estructura del documento anterior y corrige la denominación a ANF. Revisar y completar los nombres y aportes del equipo según los datos ya consignados; no inventar integrantes. Los catálogos completos están dentro del documento.

Completado en esta entrega: propuesta visual editable, activos SVG/PNG, paleta, ejemplo HTML, dos skills reutilizables, migración aplicada en Supabase (versión 20261021041732), catálogos JSON, tipos TypeScript reales y verificaciones remotas. Pendiente: crear la primera cuenta administrativa, construir/conectar la aplicación React, implementar administración segura de Auth, probar sesiones reales y documentar la demostración final. Las pruebas locales no acreditan una implementación remota terminada.

Leer `02_CONTEXTO_SUPABASE_MODELO_Y_SEGURIDAD.md` para el contrato técnico y la migración aplicada y los pendientes de integración; y `03_CONTEXTO_BRANDING_UI_Y_CONSTRUCCION.md` para identidad, pantallas y plan de interfaz.
