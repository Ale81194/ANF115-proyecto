---
name: carlitos-brand-ui
description: Diseñar y modificar pantallas, componentes React, HTML y recursos de identidad de Panadería Carlitos para ANF Análisis Financiero. Usar al construir los siete módulos, aplicar su paleta o revisar coherencia y accesibilidad de la interfaz.
---

# Interfaz de Panadería Carlitos

Leer `references/contexto_ui.md` y `references/alcance.md` antes de diseñar. Usar `assets/tokens.css` y `assets/tokens.json` como fuente de colores. Reutilizar los logos SVG de `assets`; presentarlos como propuesta académica, no como identidad oficial verificada.

## Mantener el alcance

Conservar exactamente siete módulos y este orden de navegación: Usuarios, Ingresos, Gastos, Categorías, Panel financiero, Reportes, Seguridad y bitácora. Usar la asignatura **ANF — Análisis Financiero**, nunca ANAF. Conservar React, TypeScript, Vite y Supabase/PostgreSQL. No añadir módulos de presupuestos, proyecciones, contabilidad general, inventario o nómina. Tratar las 47 cuentas contables como anexo de referencia; usar las 26 categorías para operación.

## Construir la pantalla

1. Identificar módulo, rol y tarea; mostrar período y alcance de datos cuando correspondan.
2. Usar fondo crema, superficies blancas, títulos café y acciones terracota. Reservar dorado para acentos; evitar texto dorado pequeño sobre blanco.
3. Usar Georgia/Liberation Serif para títulos y Arial/Liberation Sans para texto. No redistribuir fuentes.
4. Formatear USD con dos decimales y cifras tabulares a la derecha. Mostrar I, G, I−G y G/I×100; mostrar “No aplica” si I=0. Permitir resultado negativo.
5. Mantener etiquetas de formularios, foco visible, mensajes junto al campo y estados de carga, error, vacío y acceso restringido. No transmitir información solo por color.
6. Adaptar tarjetas y formularios a móvil; limitar el desplazamiento horizontal a contenedores de tablas. Respetar reducción de movimiento y teclado.
7. Verificar a 390 px y escritorio, zoom y filtros; contrastar cifras con el caso 12000/9600/2400/80 y período vacío.

## Respetar datos y permisos

Mostrar al administrador todos los movimientos autorizados y al empleado solamente los propios. Administrar usuarios, categorías y bitácora solo con permiso administrativo real. Ocultar botones no sustituye RLS. Solicitar motivo al anular y conservar el historial; no presentar un borrado físico.

Reutilizar el ejemplo local como referencia visual, distinguiendo su selección simulada de rol de Auth real. Escapar contenido del usuario; no incorporar claves privilegiadas al cliente. No declarar terminada la integración con Supabase sin comprobarla. Conservar el Word académico con sus espacios y tipografía propios, sin imponerle el diseño de producto.
