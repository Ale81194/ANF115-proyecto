---
name: carlitos-supabase
description: Mantener el modelo PostgreSQL, políticas RLS, migraciones y consultas Supabase de Panadería Carlitos para ANF Análisis Financiero. Usar al cambiar tablas, atributos, roles, reportes, integridad, auditoría o conectar la aplicación a su base de datos.
---

# Supabase para Panadería Carlitos

Leer `references/modelo_seguridad.md` y `references/alcance.md` antes de trabajar. Aplicar también la skill oficial de Supabase disponible. Tratar el estado registrado al 21 de octubre de 2026 como una inspección histórica: la migración propuesta estaba probada localmente y **no aplicada en remoto**.

## Inspeccionar antes de cambiar

Confirmar el proyecto `ANF_PANADERIA_CARLITOS`, referencia `zroatijmzqbdxqirvyvu`, con herramientas actuales. Comprobar esquema, datos, Auth, políticas, dependencias y migraciones. No tomar la referencia pública por una credencial ni incluir secretos en artefactos.

La revisión automática rechazó archivar veinte tablas, dos vistas y doce funciones y revocar sus privilegios. No repetir esa operación por otra vía sin la autorización explícita solicitada para ese cambio concreto. Completar análisis y pruebas aisladas mientras siga pendiente. Obtener respaldo restaurable antes de un cambio estructural; no considerar los JSON de inspección un pg_dump.

## Conservar el contrato objetivo

Mantener cinco entidades operativas: perfiles, categorias, ingresos, gastos y bitacora; exactamente dos roles: administrador y empleado. Sostener los siete módulos de la guía sin recuperar asientos, presupuestos ni escenarios. Escribir ANF — Análisis Financiero. Conservar React/TypeScript/Vite y Supabase/PostgreSQL.

Usar numeric exacto con monto positivo, finito y escala máxima de dos decimales; fecha date; categorías activas y compatibles. Mantener creador e identidad inmutables; anulación con motivo sin borrado físico ni reactivación. Preservar referencias históricas y auditoría de solo anexado. No insertar movimientos ficticios en producción.

## Aplicar seguridad

Activar RLS en toda tabla expuesta. Derivar permisos del perfil activo vinculado a auth.uid(); nunca de user_metadata. Crear cuentas inicialmente como empleado inactivo. Proteger al último administrador activo y gestionar la primera promoción desde SQL confiable con identidad verificada.

Limitar empleados a sus movimientos y consultas propias; reservar cuentas, categorías y bitácora administrativa al administrador. Mantener helpers SECURITY DEFINER en private, con search_path vacío y ejecución restringida. Conservar vista security_invoker y RPC SECURITY INVOKER para que los reportes respeten RLS. No exponer private ni el archivo legacy mediante la API.

Crear cuentas Auth desde servidor que verifique al administrador; nunca enviar secret/service_role a Vite o HTML. Distinguir bitácora de negocio de eventos de Auth. Usar parámetros y comprobar errores antes de afirmar éxito.

## Verificar y documentar

Comprobar cuatro indicadores: I, G, I−G y G/I×100 solo si I>0; devolver null en caso contrario. Probar reportes diarios, mensuales y anuales, filtros y períodos sin datos. Probar permisos como administrador, empleado, inactivo y anónimo; ataques de elevación, categorías incompatibles, montos inválidos y anulaciones.

Distinguir pruebas locales con Auth simulado de pruebas reales del proyecto. Tras una migración autorizada, revisar asesores, generar tipos TypeScript del esquema nuevo, validar sesiones y documentar resultados. No declarar corregida la base remota por disponer únicamente del SQL o de 52 comprobaciones locales.
