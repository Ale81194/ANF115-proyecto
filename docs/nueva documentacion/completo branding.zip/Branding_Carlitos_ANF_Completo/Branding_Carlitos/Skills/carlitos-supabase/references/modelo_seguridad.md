# Modelo y seguridad de Supabase para Panadería Carlitos

**Asignatura:** ANF — Análisis Financiero. **Actualización:** 21 de octubre de 2026. **Proyecto inspeccionado:** `ANF_PANADERIA_CARLITOS`, referencia `zroatijmzqbdxqirvyvu`. Esta referencia no es una credencial.

## Estado real y límites de esta entrega

La migración está **APLICADA en el proyecto remoto**. Tras la autorización de la usuaria y una nueva inspección, Supabase confirmó el éxito de `adaptar_carlitos_siete_modulos_anf`, versión `20261021041732`. Se verificaron las cinco tablas con RLS, 26 categorías, 12 políticas, las tres RPC invoker y el archivo conservado. La integración de la aplicación y la primera cuenta real siguen pendientes.

La inspección remota previa encontró PostgreSQL 17.11, veinte tablas, dos vistas, doce funciones y cuarenta políticas del diseño anterior; cero cuentas de Auth, cero perfiles y cero movimientos operativos. Los únicos registros existentes eran 105 semillas: tres roles, 48 períodos, 47 cuentas, tres tipos de estado y cuatro indicadores. No se detectaron Edge Functions ni buckets de Storage. El estado puede cambiar después de esta inspección; volver a comprobarlo antes de ejecutar.

El cambio aplicado retiró de la operación pública los presupuestos, escenarios, proyecciones y asientos. Se conservaron sus objetos y semillas en un archivo privado llamado `legacy_anf_20261020`. El esquema vigente tiene cinco tablas operativas que sostienen los siete módulos de la guía.

## Modelo vigente

| Tabla | Clave y relaciones | Atributos y restricciones principales |
|---|---|---|
| perfiles | usuario_id UUID, PK y FK a auth.users | nombre 2–120 caracteres; rol administrador/empleado; activo; creado_en; actualizado_en. Alta como empleado inactivo. |
| categorias | id UUID PK; codigo único | codigo I/G y 2–4 dígitos; nombre 2–100; tipo ingreso/gasto coherente con prefijo; descripcion hasta 500; activo; timestamps. Nombre único por tipo sin distinguir mayúsculas ni espacios exteriores. |
| ingresos | id UUID PK; categoria_id y actores FK | Campos de movimiento descritos debajo; categoría de ingreso obligatoria. |
| gastos | id UUID PK; categoria_id y actores FK | Mismos campos; categoría de gasto obligatoria. |
| bitacora | id UUID PK; actor_id FK nullable | fecha_hora; accion INSERT/UPDATE/ANULAR/MIGRACION; entidad; registro_id; motivo; antes/despues JSONB. Solo inserción por disparadores del servidor. |

### Contrato común de ingresos y gastos

| Campo | Tipo | Regla |
|---|---|---|
| id | uuid | Generado; identidad inmutable. |
| fecha | date | Obligatoria y finita; sin conversión de zona horaria. |
| concepto | text | Entre 2 y 250 caracteres después de trim. |
| monto | numeric | >0, ≤999999999999.99 y escala ≤2; rechazar fracciones de centavo. |
| categoria_id | uuid | FK restrict; tipo correcto y activa al registrar/cambiar clasificación. |
| referencia | text nullable | Hasta 120 caracteres. |
| estado | text | vigente o anulado; predeterminado vigente. |
| creado_por | uuid | Usuario autenticado; FK; no editable por el cliente. |
| creado_en | timestamptz | Generado e inmutable. |
| actualizado_por | uuid nullable | Actor asignado por servidor al modificar. |
| actualizado_en | timestamptz | Asignado por servidor. |
| revision | integer | Inicial 1; incremento por modificación. |
| solicitud_id | uuid | Clave única por creador, para reconocer reintentos de alta; conservar el mismo UUID en el reintento. |
| motivo_anulacion | text nullable | 5–500 caracteres al anular. |
| anulado_por / anulado_en | uuid / timestamptz nullable | Los completa el servidor; presentes únicamente en anulación. |

Las claves foráneas usan `ON DELETE RESTRICT`. Las categorías usadas conservan código y tipo. Desactivar una categoría impide nuevas capturas, pero conserva su interpretación histórica. Una fila anulada no admite modificaciones ni reactivación. Las tablas de movimientos no conceden DELETE al cliente. La bitácora rechaza UPDATE y DELETE.

Los índices cubren creador+fecha, fechas de movimientos vigentes, categorías, actores y consultas de auditoría. No crear índices duplicados sin medir consultas reales.

## Matriz de autorización

| Recurso | Administrador activo | Empleado activo | Inactivo / anónimo |
|---|---|---|---|
| Perfiles | Consultar todos; actualizar nombre, rol y activo | Consultar su perfil | Sin acceso operativo |
| Crear cuenta Auth | Servicio administrativo seguro, por implementar | No | No |
| Categorías | Consultar, crear, editar, desactivar | Consultar activas e históricas necesarias | No |
| Ingresos y gastos | Consultar y modificar todos los vigentes; registrar a su nombre; anular | Consultar/registrar/modificar/anular propios vigentes | No |
| Panel y reportes | Todos los movimientos autorizados | Solo propios | No |
| Bitácora | Consultar | No | No |
| Archivo legacy | Solo mantenimiento administrativo de BD | No | No |

Las cinco tablas tienen RLS. Las políticas consultan `private.rol_actual()` a partir de `auth.uid()` y del perfil activo almacenado. Nunca autorizan con `raw_user_meta_data`. Las funciones privilegiadas de disparador están en `private`, usan `SECURITY DEFINER`, referencias cualificadas y `search_path=''`; se revoca su ejecución directa. La función de rol solo devuelve el rol del propio usuario y tiene ejecución concedida al rol autenticado.

`public.v_movimientos` usa `security_invoker=true`. Las tres RPC públicas son `SECURITY INVOKER`: respetan RLS y no amplían el alcance del empleado. No colocar `private` ni `legacy_anf_20261020` entre los esquemas expuestos de la API. Revocar acceso de PUBLIC, anon, authenticated y service_role al archivo reduce el acceso desde clientes; el administrador de PostgreSQL sigue pudiendo mantenerlo.

## Funciones de consulta

| Función | Parámetros | Respuesta |
|---|---|---|
| resumen_financiero | p_desde date, p_hasta date | JSON con desde, hasta, moneda USD, ingresos, gastos, resultado, porcentaje_gastos y cantidades. |
| reporte_movimientos | fechas; p_categoria_id UUID nullable; p_tipo ingreso/gasto nullable | Filas vigentes autorizadas con tipo, fecha, concepto, monto, categoría y creador. |
| reporte_periodico | fechas; p_granularidad dia/mes/anio | Filas con período, ingresos, gastos, resultado y porcentaje; completa períodos vacíos con ceros. |

Las fechas son inclusivas. Las RPC rechazan valores nulos/infinito, rango invertido y diferencia superior a 3660 días. El porcentaje devuelve null cuando no hay ingresos. Los reportes periódicos agrupan solo las fechas solicitadas aunque el rango empiece a mitad del mes/año.

Ejemplo para conectar la aplicación al esquema vigente. Los tipos reales generados están en `Artefactos/Supabase/database.types.ts`:

```ts
const { data, error } = await supabase.rpc('resumen_financiero', {
  p_desde: '2026-10-01', p_hasta: '2026-10-31'
});
if (error) throw error;
// Renderizar null como “No aplica”; no reemplazarlo por 0 %.
```

Para registrar, enviar únicamente fecha, concepto, monto, categoria_id, referencia y solicitud_id. Para actualizar, incluir el identificador y comparar `revision` con la versión cargada mediante filtro; comprobar que se actualizó exactamente una fila y recargar si fue cero. La revisión es un mecanismo disponible para detectar ediciones concurrentes; el cliente debe implementarlo. No enviar creador, roles, fechas de auditoría ni otros campos administrados por servidor.

## Alta de usuarios y primer administrador

El disparador de Auth crea siempre un perfil empleado inactivo. El nombre puede proceder de los metadatos, con longitud y validación; no el rol. No crear usuarios ficticios ni contraseñas en migraciones.

La migración ya está verificada. Crear una cuenta real por Supabase Auth con el correo de la persona responsable. Promover **solo la primera** desde una sesión administrativa de SQL verificada, sin JWT de usuario: localizar su UUID exacto en Auth, comprobar el correo y actualizar su perfil a administrador activo dentro de una transacción. El ejemplo `02_primer_administrador.sql.example` contiene un marcador que debe sustituirse, aborta si ya hay un administrador activo y no se ejecuta automáticamente. No asignar de oficio una identidad a la usuaria.

Las altas posteriores deben pasar por una función del servidor que valide la sesión con Auth, compruebe que el solicitante es administrador activo, limite los campos admitidos, invoque la API administrativa de Auth y active/asigne el perfil según la autorización. Manejar errores parciales para no dejar cuentas activas sin perfil correcto. Esa función todavía **no está implementada ni desplegada**. La API administrativa no pertenece al navegador. Usar la clave pública/publishable con RLS en cliente; mantener secret/service_role solo en servidor.

Los hashes de contraseña son responsabilidad de Auth; no crear columnas de contraseña en perfiles. Probar inicio/cierre de sesión, recuperación, expiración y desactivación con sesiones reales después de integrar. La bitácora de tablas registra cambios de negocio; los eventos de inicio de sesión requieren revisar los registros de Auth o implementar su incorporación segura, sin fingir que ya están en bitacora.

## Migración aplicada y verificación remota

1. Se recibió autorización de la usuaria para ejecutar el cambio descrito. La nueva inspección confirmó cero usuarios y operaciones y los veinte objetos de tabla anteriores.
2. Se aplicó una migración transaccional completa mediante Supabase, versión `20261021041732`, nombre `adaptar_carlitos_siete_modulos_anf`. No volver a ejecutar el SQL: no es idempotente y su guard exige el estado previo.
3. Se conservaron veinte tablas, dos vistas y doce funciones en `legacy_anf_20261020`, con sus datos; se revocó el acceso de los roles cliente al archivo. Se verificó que las 47 cuentas de referencia siguen presentes.
4. Se verificaron cinco tablas operativas públicas con RLS, 26 categorías, 12 políticas, una vista `security_invoker` y tres funciones públicas `SECURITY INVOKER`. Quedaron cero ingresos, cero gastos, cero usuarios y un evento MIGRACION.
5. El asesor de seguridad devolvió cero hallazgos. Los avisos de rendimiento corresponden a índices sin uso por falta de actividad y a relaciones/políticas conservadas en el archivo anterior, que no es operativo. No se eliminaron índices del modelo nuevo por estar recién creados. Referencias: https://supabase.com/docs/guides/database/database-linter?lint=0001_unindexed_foreign_keys y https://supabase.com/docs/guides/database/database-linter?lint=0006_multiple_permissive_policies.
6. Una prueba transaccional real comprobó que authenticated sin perfil no accede a movimientos ni ejecuta el resumen; anon carece de permisos de lectura, ejecución del resumen y uso del archivo. Terminó con rollback sin crear cuentas ni movimientos. Se generaron tipos TypeScript del esquema remoto.
7. Pendiente: crear/verificar la primera cuenta real y promoverla a administrador; conectar React y ejecutar pruebas de sesiones, administrador/empleado, concurrencia y restauración. No confundir la migración completada con la aplicación final ya implementada.

La evidencia remota se incluye en `verificacion_remota.json`; las pruebas locales se conservan separadas porque se ejecutaron antes de aplicar el cambio. Los JSON de inspección no equivalen a un respaldo restaurable completo. El archivo preserva datos y objetos del modelo anterior, pero no se ha ensayado una restauración ni una reversión automática.

La aplicación del modelo anterior podría dejar de funcionar al mover sus objetos y cambiar permisos. Conservar el archivo permite recuperar información, pero no representa una reversión automática: una reversión posterior necesita plan y migración revisados, especialmente si el sistema nuevo ya recibió datos.

## Pruebas y evidencias incluidas

`resultado_pruebas_locales.json` documenta **52 comprobaciones aprobadas** en PGlite/PostgreSQL local. Se simuló `auth.users` y la función `auth.uid()`; se reconstruyeron columnas y semillas antiguas y objetos auxiliares mínimos. La prueba verifica el SQL objetivo, no reproduce todas las dependencias reales del esquema previo ni el servicio Auth remoto ni concurrencia entre conexiones.

Cubre cinco tablas, 26 categorías, conservación de las veinte tablas y 47 cuentas, RLS, vista invoker, altas sin privilegios por metadatos, totales 12000/9600/2400/80, períodos vacíos, reporte diario/mensual/anual, filtros, montos inválidos, categoría incompatible/inactiva, propiedad, elevación de rol bloqueada, bitácora protegida, solicitud duplicada, anulación, cuenta desactivada, último administrador, anónimo y archivo privado. Los datos ficticios se revierten al terminar.

La carpeta `pruebas_locales` incluye script, fixture y dependencias declaradas. Ejecutar en copia local aislada con Node 24: `npm install` y `npm test`. No suministrar credenciales ni apuntar ese script al proyecto remoto. Quedan pendientes pruebas de concurrencia y de integración end-to-end con Supabase real, además de un ensayo de restauración.

## Respaldo y mantenimiento

Antes de cambios estructurales, producir respaldo PostgreSQL con esquema y datos y registrar cómo restaurarlo. Auth/Storage requieren sus propios procedimientos; no asumir que exportar tablas públicas es respaldo total. Definir frecuencia, retención y responsable conforme al entorno real, y verificar una restauración aislada. No prometer una capacidad de backup/PITR o una retención que no se haya confirmado en el plan contratado.

Consultar las recomendaciones vigentes de Supabase antes de desplegar. Las fuentes primarias revisadas durante la preparación fueron la documentación oficial de Row Level Security, Database Functions, Users, Password-based Auth y el changelog de Supabase; la verificación estructural remota ya se realizó; quedan pendientes las pruebas de sesiones reales y de la aplicación. No volver a ejecutar una operación rechazada mediante otra herramienta sin la autorización explícita solicitada.
