const fs=require('fs');const {PGlite}=require('@electric-sql/pglite');
(async()=>{const db=new PGlite();await db.waitReady;
await db.exec(`create role anon;create role authenticated;create role service_role bypassrls;create role supabase_admin;create schema auth;grant usage on schema auth to anon,authenticated;create table auth.users(id uuid primary key,email text,raw_user_meta_data jsonb default '{}'::jsonb,raw_app_meta_data jsonb default '{}'::jsonb);create function auth.uid() returns uuid language sql stable as $$select coalesce(nullif(current_setting('request.jwt.claim.sub',true),''),(nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub'))::uuid$$;`);
const old=JSON.parse(fs.readFileSync('db_before_schema.json','utf8'));const rows=JSON.parse(fs.readFileSync('db_before_data.json','utf8'));
for(const t of old.tables){const name=t.name.split('.')[1];await db.exec(`create table ${t.name} (${t.columns.map(c=>`"${c.name}" ${c.data_type}`).join(',')});`);if(rows[name]?.length)await db.query(`insert into ${t.name} select * from jsonb_populate_recordset(null::${t.name},$1::jsonb)`,[JSON.stringify(rows[name])]);}
for(const v of old.metadata.views)await db.exec(`create view public.${v.viewname} as select 1 as placeholder;`);
for(const f of old.metadata.functions)await db.exec(`create function public.${f.proname}() returns boolean language sql as $$select false$$;`);
try{await db.exec(fs.readFileSync('../01_migracion_siete_modulos.sql','utf8'));console.log('MIGRATION OK');}
catch(e){console.error('MIGRATION FAILED',e.message,e.position,e.query?.slice(0,500));process.exitCode=1;return;}
const tests=[];async function check(name,sql,expected){const r=await db.query(sql);const raw=r.rows[0]?.v;const actual=typeof expected==='number' ? Number(raw) : raw;const pass=JSON.stringify(actual)===JSON.stringify(expected);tests.push({name,pass,actual,expected});if(!pass)throw Error(name+': '+JSON.stringify(actual));}
async function fails(name,sql,codes){try{await db.exec(sql);tests.push({name,pass:false});throw Error('Expected failure '+name)}catch(e){if(e.message.startsWith('Expected failure'))throw e;const pass=codes.includes(e.code);tests.push({name,pass,code:e.code});if(!pass)throw e;}}
const users={admin:'10000000-0000-4000-8000-000000000001',admin2:'10000000-0000-4000-8000-000000000002',emp:'10000000-0000-4000-8000-000000000003',other:'10000000-0000-4000-8000-000000000004',inactive:'10000000-0000-4000-8000-000000000005'};
async function as(uid){await db.exec(`reset role;select set_config('request.jwt.claim.sub','${uid}',false);set role authenticated;`)}
try{
await check('Cinco tablas operativas',`select count(*)::int as v from information_schema.tables where table_schema='public' and table_type='BASE TABLE'`,5);
await check('26 categorías exactas',`select count(*)::int as v from public.categorias`,26);
await check('20 tablas antiguas conservadas',`select count(*)::int as v from information_schema.tables where table_schema='legacy_anf_20261020' and table_type='BASE TABLE'`,20);
await check('47 cuentas antiguas conservadas',`select count(*)::int as v from legacy_anf_20261020.cuentas_contables`,47);
await check('RLS activada en cinco tablas',`select count(*)::int as v from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' and c.relrowsecurity`,5);
await check('Vista usa security_invoker',`select reloptions::text as v from pg_class where oid='public.v_movimientos'::regclass`,'{security_invoker=true}');
await db.exec('begin;');
for(const [name,id]of Object.entries(users))await db.query(`insert into auth.users(id,email,raw_user_meta_data) values($1,$2,$3::jsonb)`,[id,`${name}@example.invalid`,JSON.stringify({nombre:'Cuenta de prueba '+name,rol:'administrador'})]);
await check('Alta ignora el rol de user_metadata',`select count(*)::int as v from public.perfiles where rol='empleado' and activo=false`,5);
await db.exec(`update public.perfiles set rol='administrador',activo=true where usuario_id in ('${users.admin}','${users.admin2}');update public.perfiles set activo=true where usuario_id in ('${users.emp}','${users.other}');`);
await as(users.admin);
await check('Rol administrativo real',`select private.rol_actual() as v`,'administrador');
await db.exec(`insert into public.ingresos(fecha,concepto,monto,categoria_id) select '2026-10-01','Venta de prueba',12000,id from public.categorias where codigo='I01';insert into public.gastos(fecha,concepto,monto,categoria_id) select '2026-10-02','Pago de prueba',9600,id from public.categorias where codigo='G01';`);
await check('Ingresos totales',`select (public.resumen_financiero('2026-10-01','2026-10-31')->>'ingresos')::numeric as v`,12000);
await check('Gastos totales',`select (public.resumen_financiero('2026-10-01','2026-10-31')->>'gastos')::numeric as v`,9600);
await check('Resultado',`select (public.resumen_financiero('2026-10-01','2026-10-31')->>'resultado')::numeric as v`,2400);
await check('Porcentaje',`select (public.resumen_financiero('2026-10-01','2026-10-31')->>'porcentaje_gastos')::numeric as v`,80);
await check('Sin ingresos devuelve null',`select public.resumen_financiero('2027-01-01','2027-01-31')->'porcentaje_gastos' as v`,null);
await check('Reporte diario completa días vacíos',`select count(*)::int as v from public.reporte_periodico('2026-10-01','2026-10-31','dia')`,31);
await check('Reporte mensual',`select resultado as v from public.reporte_periodico('2026-10-01','2026-10-31','mes')`,2400);
await check('Reporte anual',`select resultado as v from public.reporte_periodico('2026-01-01','2026-12-31','anio')`,2400);
await check('Reporte filtrado por tipo',`select count(*)::int as v from public.reporte_movimientos('2026-10-01','2026-10-31',null,'ingreso')`,1);
// Savepoints allow expected errors without aborting the full verification transaction.
async function expectedError(name,sql,codes){await db.exec('savepoint expected_failure;');try{await db.exec(sql);await db.exec('rollback to savepoint expected_failure;');throw Error('Expected failure '+name)}catch(e){await db.exec('rollback to savepoint expected_failure;');const pass=codes.includes(e.code);tests.push({name,pass,code:e.code});if(!pass)throw e;}}
await expectedError('Rango invertido rechazado',`select public.resumen_financiero('2026-10-31','2026-10-01')`,['22023']);
for(const [name,value]of [['Cero','0'],['Negativo','-1'],['Fracción de centavo','1.001'],['No numérico finito',"'NaN'::numeric"]])await expectedError(name,`insert into public.ingresos(fecha,concepto,monto,categoria_id) select '2026-10-03','Dato inválido',${value},id from public.categorias where codigo='I01'`,['23514']);
await expectedError('Categoría incompatible rechazada',`insert into public.ingresos(fecha,concepto,monto,categoria_id) select '2026-10-03','Dato incompatible',1,id from public.categorias where codigo='G01'`,['23514']);
await expectedError('No cambiar tipo de categoría usada',`update public.categorias set tipo='gasto',codigo='G99' where codigo='I01'`,['23514']);
await as(users.emp);
await check('Empleado no hereda user_metadata',`select private.rol_actual() as v`,'empleado');
await check('Empleado no ve ingresos ajenos',`select count(*)::int as v from public.ingresos`,0);
await check('Vista respeta RLS',`select count(*)::int as v from public.v_movimientos`,0);
await check('RPC respeta RLS',`select (public.resumen_financiero('2026-10-01','2026-10-31')->>'ingresos')::numeric as v`,0);
await expectedError('Empleado no crea categorías',`insert into public.categorias(codigo,nombre,tipo) values('I99','No autorizado','ingreso')`,['42501']);
await expectedError('Empleado no escribe bitácora',`insert into public.bitacora(accion,entidad) values('INSERT','falso')`,['42501']);
await check('Empleado no ve bitácora administrativa',`select count(*)::int as v from public.bitacora`,0);
await db.exec(`update public.perfiles set rol='administrador' where usuario_id='${users.emp}';`);
await check('Intento de elevar privilegios no modifica perfil',`select rol as v from public.perfiles where usuario_id='${users.emp}'`,'empleado');
await db.exec(`insert into public.ingresos(fecha,concepto,monto,categoria_id,solicitud_id) select '2026-10-04','Ingreso propio',100,id,'20000000-0000-4000-8000-000000000001' from public.categorias where codigo='I02';insert into public.gastos(fecha,concepto,monto,categoria_id) select '2026-10-05','Gasto propio',40,id from public.categorias where codigo='G06';`);
await check('Empleado ve su resultado',`select (public.resumen_financiero('2026-10-01','2026-10-31')->>'resultado')::numeric as v`,60);
await expectedError('Solicitud duplicada rechazada',`insert into public.ingresos(fecha,concepto,monto,categoria_id,solicitud_id) select '2026-10-04','Ingreso propio',100,id,'20000000-0000-4000-8000-000000000001' from public.categorias where codigo='I02'`,['23505']);
await expectedError('Creador no modificable',`update public.ingresos set creado_por='${users.other}'`,['42501']);
await expectedError('Borrado físico no permitido',`delete from public.ingresos`,['42501']);
await expectedError('Motivo de anulación obligatorio',`update public.ingresos set estado='anulado',motivo_anulacion='x'`,['23514']);
await db.exec(`update public.ingresos set estado='anulado',motivo_anulacion='Corrección de prueba';`);
await check('Anulados excluidos del resumen',`select (public.resumen_financiero('2026-10-01','2026-10-31')->>'resultado')::numeric as v`,-40);
await check('Sin ingresos tras anular: porcentaje null',`select public.resumen_financiero('2026-10-01','2026-10-31')->'porcentaje_gastos' as v`,null);
await db.exec(`update public.ingresos set estado='vigente' where creado_por='${users.emp}';`);
await check('Anulado no se reactiva',`select estado as v from public.ingresos where creado_por='${users.emp}'`,'anulado');
await as(users.other);await check('Otro empleado no ve datos del anterior',`select count(*)::int as v from public.gastos`,0);
await as(users.admin);
await check('Admin ve ambos propietarios',`select count(*)::int as v from public.gastos`,2);
await check('Anulación auditada con actor',`select count(*)::int as v from public.bitacora where accion='ANULAR' and actor_id='${users.emp}'`,1);
await db.exec(`update public.categorias set activo=false where codigo='G06';`);
await as(users.emp);
await check('Categoría inactiva histórica visible',`select count(*)::int as v from public.categorias where codigo='G06'`,1);
await expectedError('No usar categoría inactiva en nueva captura',`insert into public.gastos(fecha,concepto,monto,categoria_id) select '2026-10-08','Captura inactiva',10,id from public.categorias where codigo='G06'`,['23514']);
await as(users.admin);await db.exec(`update public.perfiles set activo=false where usuario_id='${users.emp}';`);
await as(users.emp);await expectedError('Desactivación bloquea token previo',`select public.resumen_financiero('2026-10-01','2026-10-31')`,['42501']);
await as(users.admin);await db.exec(`update public.perfiles set activo=false where usuario_id='${users.admin2}';`);
await expectedError('Último administrador protegido',`update public.perfiles set activo=false where usuario_id='${users.admin}'`,['23514']);
await db.exec('reset role;set role anon;');
await expectedError('Anon no consulta movimientos',`select * from public.ingresos`,['42501']);
await expectedError('Anon no ejecuta resumen',`select public.resumen_financiero('2026-10-01','2026-10-31')`,['42501']);
await db.exec('reset role;set role authenticated;');
await expectedError('Esquema antiguo no accesible por cliente',`select * from legacy_anf_20261020.cuentas_contables`,['42501']);
await db.exec('reset role;rollback;');
await check('Las cuentas ficticias se revierten',`select count(*)::int as v from auth.users`,0);
await check('Los movimientos de prueba se revierten',`select count(*)::int as v from public.ingresos`,0);
console.log('PASSED',tests.length,'assertions');
}catch(e){console.error('TEST FAILED',e.message,e.code);process.exitCode=1;}
const result={environment:'PGlite local PostgreSQL; Auth simulado con la misma función auth.uid. No es una ejecución en el proyecto remoto.',migration_applied_remote:false,tests,passed:tests.filter(t=>t.pass).length,total:tests.length};fs.writeFileSync('resultado_pruebas_locales.json',JSON.stringify(result,null,2));
await db.close();})();
