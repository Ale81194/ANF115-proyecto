export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      bitacora: {
        Row: {
          accion: string
          actor_id: string | null
          antes: Json | null
          despues: Json | null
          entidad: string
          fecha_hora: string
          id: string
          motivo: string | null
          registro_id: string | null
        }
        Insert: {
          accion: string
          actor_id?: string | null
          antes?: Json | null
          despues?: Json | null
          entidad: string
          fecha_hora?: string
          id?: string
          motivo?: string | null
          registro_id?: string | null
        }
        Update: {
          accion?: string
          actor_id?: string | null
          antes?: Json | null
          despues?: Json | null
          entidad?: string
          fecha_hora?: string
          id?: string
          motivo?: string | null
          registro_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bitacora_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "perfiles"
            referencedColumns: ["usuario_id"]
          },
        ]
      }
      categorias: {
        Row: {
          activo: boolean
          actualizado_en: string
          codigo: string
          creado_en: string
          descripcion: string
          id: string
          nombre: string
          tipo: string
        }
        Insert: {
          activo?: boolean
          actualizado_en?: string
          codigo: string
          creado_en?: string
          descripcion?: string
          id?: string
          nombre: string
          tipo: string
        }
        Update: {
          activo?: boolean
          actualizado_en?: string
          codigo?: string
          creado_en?: string
          descripcion?: string
          id?: string
          nombre?: string
          tipo?: string
        }
        Relationships: []
      }
      gastos: {
        Row: {
          actualizado_en: string
          actualizado_por: string | null
          anulado_en: string | null
          anulado_por: string | null
          categoria_id: string
          concepto: string
          creado_en: string
          creado_por: string
          estado: string
          fecha: string
          id: string
          monto: number
          motivo_anulacion: string | null
          referencia: string | null
          revision: number
          solicitud_id: string
        }
        Insert: {
          actualizado_en?: string
          actualizado_por?: string | null
          anulado_en?: string | null
          anulado_por?: string | null
          categoria_id: string
          concepto: string
          creado_en?: string
          creado_por?: string
          estado?: string
          fecha: string
          id?: string
          monto: number
          motivo_anulacion?: string | null
          referencia?: string | null
          revision?: number
          solicitud_id?: string
        }
        Update: {
          actualizado_en?: string
          actualizado_por?: string | null
          anulado_en?: string | null
          anulado_por?: string | null
          categoria_id?: string
          concepto?: string
          creado_en?: string
          creado_por?: string
          estado?: string
          fecha?: string
          id?: string
          monto?: number
          motivo_anulacion?: string | null
          referencia?: string | null
          revision?: number
          solicitud_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "gastos_actualizado_por_fkey"
            columns: ["actualizado_por"]
            isOneToOne: false
            referencedRelation: "perfiles"
            referencedColumns: ["usuario_id"]
          },
          {
            foreignKeyName: "gastos_anulado_por_fkey"
            columns: ["anulado_por"]
            isOneToOne: false
            referencedRelation: "perfiles"
            referencedColumns: ["usuario_id"]
          },
          {
            foreignKeyName: "gastos_categoria_id_fkey"
            columns: ["categoria_id"]
            isOneToOne: false
            referencedRelation: "categorias"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "gastos_creado_por_fkey"
            columns: ["creado_por"]
            isOneToOne: false
            referencedRelation: "perfiles"
            referencedColumns: ["usuario_id"]
          },
        ]
      }
      ingresos: {
        Row: {
          actualizado_en: string
          actualizado_por: string | null
          anulado_en: string | null
          anulado_por: string | null
          categoria_id: string
          concepto: string
          creado_en: string
          creado_por: string
          estado: string
          fecha: string
          id: string
          monto: number
          motivo_anulacion: string | null
          referencia: string | null
          revision: number
          solicitud_id: string
        }
        Insert: {
          actualizado_en?: string
          actualizado_por?: string | null
          anulado_en?: string | null
          anulado_por?: string | null
          categoria_id: string
          concepto: string
          creado_en?: string
          creado_por?: string
          estado?: string
          fecha: string
          id?: string
          monto: number
          motivo_anulacion?: string | null
          referencia?: string | null
          revision?: number
          solicitud_id?: string
        }
        Update: {
          actualizado_en?: string
          actualizado_por?: string | null
          anulado_en?: string | null
          anulado_por?: string | null
          categoria_id?: string
          concepto?: string
          creado_en?: string
          creado_por?: string
          estado?: string
          fecha?: string
          id?: string
          monto?: number
          motivo_anulacion?: string | null
          referencia?: string | null
          revision?: number
          solicitud_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ingresos_actualizado_por_fkey"
            columns: ["actualizado_por"]
            isOneToOne: false
            referencedRelation: "perfiles"
            referencedColumns: ["usuario_id"]
          },
          {
            foreignKeyName: "ingresos_anulado_por_fkey"
            columns: ["anulado_por"]
            isOneToOne: false
            referencedRelation: "perfiles"
            referencedColumns: ["usuario_id"]
          },
          {
            foreignKeyName: "ingresos_categoria_id_fkey"
            columns: ["categoria_id"]
            isOneToOne: false
            referencedRelation: "categorias"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ingresos_creado_por_fkey"
            columns: ["creado_por"]
            isOneToOne: false
            referencedRelation: "perfiles"
            referencedColumns: ["usuario_id"]
          },
        ]
      }
      perfiles: {
        Row: {
          activo: boolean
          actualizado_en: string
          creado_en: string
          nombre: string
          rol: string
          usuario_id: string
        }
        Insert: {
          activo?: boolean
          actualizado_en?: string
          creado_en?: string
          nombre: string
          rol?: string
          usuario_id: string
        }
        Update: {
          activo?: boolean
          actualizado_en?: string
          creado_en?: string
          nombre?: string
          rol?: string
          usuario_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      v_movimientos: {
        Row: {
          categoria_id: string | null
          concepto: string | null
          creado_por: string | null
          estado: string | null
          fecha: string | null
          id: string | null
          monto: number | null
          revision: number | null
          tipo: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      reporte_movimientos: {
        Args: {
          p_categoria_id?: string
          p_desde: string
          p_hasta: string
          p_tipo?: string
        }
        Returns: {
          categoria: string
          categoria_id: string
          codigo_categoria: string
          concepto: string
          creado_por: string
          fecha: string
          id: string
          monto: number
          tipo: string
        }[]
      }
      reporte_periodico: {
        Args: { p_desde: string; p_granularidad?: string; p_hasta: string }
        Returns: {
          gastos: number
          ingresos: number
          periodo: string
          porcentaje_gastos: number
          resultado: number
        }[]
      }
      resumen_financiero: {
        Args: { p_desde: string; p_hasta: string }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const

