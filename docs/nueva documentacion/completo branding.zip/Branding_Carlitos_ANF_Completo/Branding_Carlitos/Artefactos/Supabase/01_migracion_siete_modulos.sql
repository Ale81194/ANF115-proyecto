-- APLICADA en Supabase: versión 20261021041732, adaptar_carlitos_siete_modulos_anf.
-- SQL histórico de la migración aplicada. NO REEJECUTAR; no es idempotente.
-- Precondiciones transaccionales: sin usuarios ni actividad financiera; abortar si el estado cambió.
DO $guard$
DECLARE t record; n bigint;
BEGIN
 IF EXISTS (SELECT 1 FROM auth.users) THEN RAISE EXCEPTION 'Aparecieron usuarios: revisar la migración antes de continuar'; END IF;
 FOR t IN SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' AND table_name NOT IN ('roles','cuentas_contables','periodos_contables','tipos_estado_financiero','indicadores_financieros') LOOP
  EXECUTE format('SELECT count(*) FROM public.%I',t.table_name) INTO n;
  IF n<>0 THEN RAISE EXCEPTION 'La tabla % contiene datos; revisar antes de archivar',t.table_name; END IF;
 END LOOP;
 IF (SELECT count(*) FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE')<>20 THEN RAISE EXCEPTION 'El esquema cambió desde la inspección'; END IF;
END $guard$;
-- Panadería Carlitos. Adaptación a siete módulos ANF115.
-- Aplicación remota mediante una migración transaccional.
-- Conserva íntegramente el esquema anterior en legacy_anf_20261020.
create schema legacy_anf_20261020;
revoke all on schema legacy_anf_20261020 from public,anon,authenticated,service_role;
create schema if not exists private;
revoke all on schema private from public,anon;
grant usage on schema private to authenticated;

alter table public.roles set schema legacy_anf_20261020;
alter table public.perfiles set schema legacy_anf_20261020;
alter table public.periodos_contables set schema legacy_anf_20261020;
alter table public.cuentas_contables set schema legacy_anf_20261020;
alter table public.lotes_importacion set schema legacy_anf_20261020;
alter table public.errores_importacion set schema legacy_anf_20261020;
alter table public.asientos_contables set schema legacy_anf_20261020;
alter table public.detalles_asiento set schema legacy_anf_20261020;
alter table public.presupuestos set schema legacy_anf_20261020;
alter table public.partidas_presupuesto set schema legacy_anf_20261020;
alter table public.escenarios set schema legacy_anf_20261020;
alter table public.supuestos_escenario set schema legacy_anf_20261020;
alter table public.partidas_proyeccion set schema legacy_anf_20261020;
alter table public.movimientos_proyeccion set schema legacy_anf_20261020;
alter table public.movimientos_patrimonio set schema legacy_anf_20261020;
alter table public.tipos_estado_financiero set schema legacy_anf_20261020;
alter table public.asignaciones_cuentas_estado set schema legacy_anf_20261020;
alter table public.exportaciones_reportes set schema legacy_anf_20261020;
alter table public.bitacora_auditoria set schema legacy_anf_20261020;
alter table public.indicadores_financieros set schema legacy_anf_20261020;
alter view public.vista_cuadre_periodos set schema legacy_anf_20261020;
alter view public.vista_balance_comprobacion set schema legacy_anf_20261020;
alter function public.es_editor_financiero() set schema legacy_anf_20261020;
alter function public.es_administrador_financiero() set schema legacy_anf_20261020;
alter function public.codigo_rol_actual() set schema legacy_anf_20261020;
alter function public.es_miembro_financiero() set schema legacy_anf_20261020;
alter function public.validar_escenario_editable() set schema legacy_anf_20261020;
alter function public.validar_contabilizacion_asiento() set schema legacy_anf_20261020;
alter function public.proteger_detalles_contabilizados() set schema legacy_anf_20261020;
alter function public.validar_aprobacion_escenario() set schema legacy_anf_20261020;
alter function public.validar_detalle_asiento() set schema legacy_anf_20261020;
alter function public.validar_presupuesto_editable() set schema legacy_anf_20261020;
alter function public.proteger_asientos_periodo_cerrado() set schema legacy_anf_20261020;
alter function public.validar_aprobacion_presupuesto() set schema legacy_anf_20261020;

revoke all on all tables in schema legacy_anf_20261020 from public,anon,authenticated,service_role;
revoke all on all sequences in schema legacy_anf_20261020 from public,anon,authenticated,service_role;
revoke all on all functions in schema legacy_anf_20261020 from public,anon,authenticated,service_role;

create table public.perfiles (
 usuario_id uuid primary key references auth.users(id) on delete restrict,
 nombre text not null check (char_length(btrim(nombre)) between 2 and 120),
 rol text not null default 'empleado' check (rol in ('administrador','empleado')),
 activo boolean not null default false,
 creado_en timestamptz not null default now(),
 actualizado_en timestamptz not null default now()
);
comment on table public.perfiles is 'Identidad en Auth; solo administrador y empleado. Alta inactiva por defecto; activación administrativa.';
create table public.categorias (
 id uuid primary key default gen_random_uuid(),
 codigo text not null unique check (codigo ~ '^[IG][0-9]{2,4}$'),
 nombre text not null check (char_length(btrim(nombre)) between 2 and 100),
 tipo text not null check (tipo in ('ingreso','gasto')),
 descripcion text not null default '' check (char_length(descripcion)<=500),
 activo boolean not null default true,
 creado_en timestamptz not null default now(),
 actualizado_en timestamptz not null default now(),
 constraint categoria_codigo_tipo check ((tipo='ingreso' and left(codigo,1)='I') or (tipo='gasto' and left(codigo,1)='G'))
);
create unique index categorias_nombre_tipo_uq on public.categorias(tipo,lower(btrim(nombre)));


create table public.ingresos (
 id uuid primary key default gen_random_uuid(),
 fecha date not null check (isfinite(fecha)),
 concepto text not null check (char_length(btrim(concepto)) between 2 and 250),
 monto numeric not null check (monto>0 and monto<=999999999999.99 and scale(monto)<=2),
 categoria_id uuid not null references public.categorias(id) on delete restrict,
 referencia text check (char_length(referencia)<=120),
 estado text not null default 'vigente' check (estado in ('vigente','anulado')),
 creado_por uuid not null default auth.uid() references public.perfiles(usuario_id) on delete restrict,
 creado_en timestamptz not null default now(),
 actualizado_por uuid references public.perfiles(usuario_id) on delete restrict,
 actualizado_en timestamptz not null default now(),
 revision integer not null default 1 check (revision>0),
 solicitud_id uuid not null default gen_random_uuid(),
 motivo_anulacion text check (char_length(motivo_anulacion)<=500),
 anulado_por uuid references public.perfiles(usuario_id) on delete restrict,
 anulado_en timestamptz,
 unique(creado_por,solicitud_id),
 constraint ingresos_anulacion_valida check (
  (estado='vigente' and motivo_anulacion is null and anulado_por is null and anulado_en is null)
  or (estado='anulado' and char_length(btrim(motivo_anulacion))>=5 and anulado_por is not null and anulado_en is not null)
 )
);
comment on column public.ingresos.monto is 'Decimal exacto con CHECK de escala: rechaza fracciones de centavo en lugar de redondearlas silenciosamente.';
create index ingresos_creador_fecha_idx on public.ingresos(creado_por,fecha);
create index ingresos_fecha_vigente_idx on public.ingresos(fecha) where estado='vigente';
create index ingresos_categoria_idx on public.ingresos(categoria_id);
create index ingresos_actualizado_por_idx on public.ingresos(actualizado_por) where actualizado_por is not null;
create index ingresos_anulado_por_idx on public.ingresos(anulado_por) where anulado_por is not null;


create table public.gastos (
 id uuid primary key default gen_random_uuid(),
 fecha date not null check (isfinite(fecha)),
 concepto text not null check (char_length(btrim(concepto)) between 2 and 250),
 monto numeric not null check (monto>0 and monto<=999999999999.99 and scale(monto)<=2),
 categoria_id uuid not null references public.categorias(id) on delete restrict,
 referencia text check (char_length(referencia)<=120),
 estado text not null default 'vigente' check (estado in ('vigente','anulado')),
 creado_por uuid not null default auth.uid() references public.perfiles(usuario_id) on delete restrict,
 creado_en timestamptz not null default now(),
 actualizado_por uuid references public.perfiles(usuario_id) on delete restrict,
 actualizado_en timestamptz not null default now(),
 revision integer not null default 1 check (revision>0),
 solicitud_id uuid not null default gen_random_uuid(),
 motivo_anulacion text check (char_length(motivo_anulacion)<=500),
 anulado_por uuid references public.perfiles(usuario_id) on delete restrict,
 anulado_en timestamptz,
 unique(creado_por,solicitud_id),
 constraint gastos_anulacion_valida check (
  (estado='vigente' and motivo_anulacion is null and anulado_por is null and anulado_en is null)
  or (estado='anulado' and char_length(btrim(motivo_anulacion))>=5 and anulado_por is not null and anulado_en is not null)
 )
);
comment on column public.gastos.monto is 'Decimal exacto con CHECK de escala: rechaza fracciones de centavo en lugar de redondearlas silenciosamente.';
create index gastos_creador_fecha_idx on public.gastos(creado_por,fecha);
create index gastos_fecha_vigente_idx on public.gastos(fecha) where estado='vigente';
create index gastos_categoria_idx on public.gastos(categoria_id);
create index gastos_actualizado_por_idx on public.gastos(actualizado_por) where actualizado_por is not null;
create index gastos_anulado_por_idx on public.gastos(anulado_por) where anulado_por is not null;


create table public.bitacora (
 id uuid primary key default gen_random_uuid(),
 actor_id uuid references public.perfiles(usuario_id) on delete restrict,
 fecha_hora timestamptz not null default clock_timestamp(),
 accion text not null check (accion in ('INSERT','UPDATE','ANULAR','MIGRACION')),
 entidad text not null,
 registro_id uuid,
 motivo text,
 antes jsonb,
 despues jsonb
);
create index bitacora_actor_fecha_idx on public.bitacora(actor_id,fecha_hora desc);
create index bitacora_fecha_idx on public.bitacora(fecha_hora desc);
create index bitacora_entidad_registro_idx on public.bitacora(entidad,registro_id);

-- Las siguientes funciones privilegiadas NO están en un esquema expuesto.
-- La consulta de rol solo consulta al usuario de auth.uid(); nunca user_metadata.
create function private.rol_actual() returns text
language sql stable security definer set search_path='' as $$
 select p.rol from public.perfiles p
 where auth.uid() is not null and p.usuario_id=(select auth.uid()) and p.activo
$$;
revoke all on function private.rol_actual() from public,anon;
grant execute on function private.rol_actual() to authenticated;

create function private.alta_perfil_auth() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if TG_TABLE_SCHEMA<>'auth' or TG_TABLE_NAME<>'users' or TG_OP<>'INSERT' then
  raise exception 'Contexto de alta inválido' using errcode='42501';
 end if;
 insert into public.perfiles(usuario_id,nombre,rol,activo)
 values(new.id,left(coalesce(nullif(btrim(new.raw_user_meta_data->>'nombre'),''),'Usuario pendiente'),120),'empleado',false);
 return new;
end $$;
revoke all on function private.alta_perfil_auth() from public,anon,authenticated;
create trigger carlitos_alta_perfil after insert on auth.users for each row execute function private.alta_perfil_auth();

create function private.proteger_perfil() returns trigger
language plpgsql security definer set search_path='' as $$
declare v_rol text:=private.rol_actual(); v_caller text:=current_setting('role',true);
begin
 if new.usuario_id is distinct from old.usuario_id or new.creado_en is distinct from old.creado_en then
  raise exception 'La identidad y la fecha de alta son inmutables' using errcode='23514';
 end if;
 if v_rol is distinct from 'administrador' and not
  (auth.uid() is null and session_user in ('postgres','supabase_admin') and coalesce(v_caller,'none') in ('none','postgres','supabase_admin')) then
  raise exception 'Solo un administrador activo puede modificar perfiles' using errcode='42501';
 end if;
 -- Serializar cambios para no desactivar concurrentemente al último administrador.
 perform pg_advisory_xact_lock(742061,1);
 if old.activo and old.rol='administrador' and (not new.activo or new.rol<>'administrador')
 and not exists(select 1 from public.perfiles where usuario_id<>old.usuario_id and activo and rol='administrador') then
  raise exception 'Debe permanecer al menos un administrador activo' using errcode='23514';
 end if;
 new.nombre:=btrim(new.nombre);new.actualizado_en:=clock_timestamp();return new;
end $$;
revoke all on function private.proteger_perfil() from public,anon,authenticated;
create trigger carlitos_guardar_perfil before update on public.perfiles for each row execute function private.proteger_perfil();

create function private.validar_categoria() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if private.rol_actual() is distinct from 'administrador' then
  raise exception 'Se requiere administrador activo' using errcode='42501';
 end if;
 if TG_OP='UPDATE' then
  if new.id is distinct from old.id or new.creado_en is distinct from old.creado_en then
   raise exception 'La identidad de la categoría es inmutable' using errcode='23514';
  end if;
  if (new.tipo is distinct from old.tipo or new.codigo is distinct from old.codigo) and
  (exists(select 1 from public.ingresos where categoria_id=old.id) or exists(select 1 from public.gastos where categoria_id=old.id)) then
   raise exception 'No cambie tipo o código de una categoría utilizada; desactívela' using errcode='23514';
  end if;
 end if;
 new.codigo:=upper(btrim(new.codigo));new.nombre:=btrim(new.nombre);
 new.actualizado_en:=clock_timestamp();return new;
end $$;
revoke all on function private.validar_categoria() from public,anon,authenticated;

create function private.validar_movimiento() returns trigger
language plpgsql security definer set search_path='' as $$
declare v_uid uuid:=auth.uid(); v_rol text:=private.rol_actual(); v_tipo text; v_cat public.categorias;
begin
 if v_uid is null or v_rol is null then
  raise exception 'Se requiere una cuenta activa' using errcode='42501';
 end if;
 if TG_TABLE_NAME not in ('ingresos','gastos') or TG_TABLE_SCHEMA<>'public' then
  raise exception 'Entidad no autorizada' using errcode='42501';
 end if;
 v_tipo:=case when TG_TABLE_NAME='ingresos' then 'ingreso' else 'gasto' end;
 if TG_OP='INSERT' then
  if new.creado_por is distinct from v_uid or new.estado<>'vigente' then
   raise exception 'Creador o estado inicial no autorizado' using errcode='42501';
  end if;
  new.creado_en:=clock_timestamp();new.actualizado_en:=new.creado_en;new.revision:=1;
 else
  if old.creado_por<>v_uid and v_rol<>'administrador' then
   raise exception 'Movimiento de otro usuario' using errcode='42501';
  end if;
  if old.estado='anulado' then
   raise exception 'Un movimiento anulado conserva su historial y no se modifica' using errcode='23514';
  end if;
  if new.id is distinct from old.id or new.creado_por is distinct from old.creado_por
   or new.creado_en is distinct from old.creado_en or new.solicitud_id is distinct from old.solicitud_id then
   raise exception 'Identidad, origen y solicitud son inmutables' using errcode='23514';
  end if;
  new.actualizado_en:=clock_timestamp();new.revision:=old.revision+1;
 end if;
 -- FOR SHARE serializa la captura con la desactivación o reclasificación de la categoría.
 -- El trigger privado verifica previamente identidad, rol y propiedad; no es RPC.
 if TG_OP='INSERT' or new.categoria_id is distinct from old.categoria_id then
  select * into v_cat from public.categorias where id=new.categoria_id for share;
  if not found or not v_cat.activo or v_cat.tipo<>v_tipo then
   raise exception 'Categoría inexistente, inactiva o incompatible' using errcode='23514';
  end if;
 end if;
 if new.estado='anulado' then
  if char_length(btrim(coalesce(new.motivo_anulacion,'')))<5 then
   raise exception 'Indique un motivo de anulación de al menos cinco caracteres' using errcode='23514';
  end if;
  new.motivo_anulacion:=btrim(new.motivo_anulacion);new.anulado_por:=v_uid;new.anulado_en:=clock_timestamp();
 else
  new.motivo_anulacion:=null;new.anulado_por:=null;new.anulado_en:=null;
 end if;
 new.concepto:=btrim(new.concepto);new.actualizado_por:=v_uid;return new;
end $$;
revoke all on function private.validar_movimiento() from public,anon,authenticated;

create function private.auditar_cambio() returns trigger
language plpgsql security definer set search_path='' as $$
declare a text:=TG_OP; rid uuid;
begin
 if TG_TABLE_SCHEMA<>'public' or TG_TABLE_NAME not in ('perfiles','categorias','ingresos','gastos') then
  raise exception 'Entidad de auditoría no autorizada';
 end if;
 if TG_OP='UPDATE' and TG_TABLE_NAME in ('ingresos','gastos') and to_jsonb(new)->>'estado'='anulado' then a:='ANULAR';end if;
 rid:=coalesce((to_jsonb(new)->>'id')::uuid,(to_jsonb(new)->>'usuario_id')::uuid);
 insert into public.bitacora(actor_id,accion,entidad,registro_id,motivo,antes,despues)
 values(auth.uid(),a,TG_TABLE_NAME,rid,to_jsonb(new)->>'motivo_anulacion',case when TG_OP='UPDATE' then to_jsonb(old) end,to_jsonb(new));
 return new;
end $$;
revoke all on function private.auditar_cambio() from public,anon,authenticated;
create function private.bitacora_inmutable() returns trigger
language plpgsql set search_path='' as $$ begin
 raise exception 'La bitácora es de solo adición mediante triggers' using errcode='42501';
end $$;
revoke all on function private.bitacora_inmutable() from public,anon,authenticated;
create trigger carlitos_bitacora_inmutable before update or delete on public.bitacora for each row execute function private.bitacora_inmutable();

-- Semilla exacta del anexo A del informe. No incluye movimientos ficticios persistentes.

insert into public.categorias(codigo,nombre,tipo,descripcion) values
('I01','Ventas de pan dulce','ingreso','Cobros por pan dulce vendido.'),
('I02','Ventas de pan francés','ingreso','Cobros por pan francés vendido.'),
('I03','Ventas de repostería','ingreso','Cobros por pasteles y otros productos de repostería.'),
('I04','Ventas de pan integral','ingreso','Cobros por productos de panadería integral.'),
('I05','Ventas de galletas','ingreso','Cobros por galletas elaboradas para la venta.'),
('I06','Pedidos especiales','ingreso','Cobros por pedidos identificados como especiales; no duplicar otra venta.'),
('G01','Ingredientes','gasto','Harina, levadura, azúcar, manteca y demás ingredientes pagados.'),
('G02','Empaques','gasto','Bolsas, cajas y otros materiales de empaque pagados.'),
('G03','Gas de producción','gasto','Pagos de gas utilizado por los hornos.'),
('G04','Energía eléctrica','gasto','Pagos del suministro de electricidad.'),
('G05','Agua','gasto','Pagos del servicio de agua.'),
('G06','Alquiler','gasto','Pagos por el uso del local.'),
('G07','Pagos de personal','gasto','Pagos operativos al personal; no constituye un módulo de nómina.'),
('G08','Transporte','gasto','Pagos de entregas y transporte relacionados con la operación.'),
('G09','Suministros','gasto','Artículos operativos y de oficina distintos de ingredientes y empaques.'),
('G10','Limpieza','gasto','Productos y servicios de limpieza.'),
('G11','Mantenimiento de equipos','gasto','Reparación y mantenimiento ordinario de hornos y equipos.'),
('G12','Mantenimiento del local','gasto','Conservación ordinaria de las instalaciones.'),
('G13','Publicidad','gasto','Pagos de publicidad y promoción.'),
('G14','Telefonía e internet','gasto','Pagos de comunicaciones del negocio.'),
('G15','Comisiones de cobro','gasto','Comisiones pagadas por medios de cobro.'),
('G16','Permisos y tasas','gasto','Pagos operativos identificados por permisos o tasas.'),
('G17','Seguros','gasto','Pagos de seguros relacionados con la operación.'),
('G18','Servicios profesionales','gasto','Pagos por servicios profesionales recibidos.'),
('G19','Uniformes y protección','gasto','Pagos por uniformes e implementos de protección.'),
('G20','Otros gastos operativos','gasto','Pagos no comprendidos en otra categoría; exigir concepto específico.');
create trigger carlitos_validar_categoria before insert or update on public.categorias for each row execute function private.validar_categoria();
create trigger carlitos_validar_ingresos before insert or update on public.ingresos for each row execute function private.validar_movimiento();
create trigger carlitos_validar_gastos before insert or update on public.gastos for each row execute function private.validar_movimiento();
create trigger carlitos_auditar_perfiles after insert or update on public.perfiles for each row execute function private.auditar_cambio();
create trigger carlitos_auditar_categorias after insert or update on public.categorias for each row execute function private.auditar_cambio();
create trigger carlitos_auditar_ingresos after insert or update on public.ingresos for each row execute function private.auditar_cambio();
create trigger carlitos_auditar_gastos after insert or update on public.gastos for each row execute function private.auditar_cambio();
alter table public.perfiles enable row level security;
revoke all on public.perfiles from public,anon,authenticated;
grant select on public.perfiles to authenticated;
alter table public.categorias enable row level security;
revoke all on public.categorias from public,anon,authenticated;
grant select on public.categorias to authenticated;
alter table public.ingresos enable row level security;
revoke all on public.ingresos from public,anon,authenticated;
grant select on public.ingresos to authenticated;
alter table public.gastos enable row level security;
revoke all on public.gastos from public,anon,authenticated;
grant select on public.gastos to authenticated;
alter table public.bitacora enable row level security;
revoke all on public.bitacora from public,anon,authenticated;
grant select on public.bitacora to authenticated;

grant update(nombre,rol,activo) on public.perfiles to authenticated;
grant insert(codigo,nombre,tipo,descripcion,activo),update(codigo,nombre,tipo,descripcion,activo) on public.categorias to authenticated;
create policy perfiles_leer on public.perfiles for select to authenticated
 using (usuario_id=(select auth.uid()) or (select private.rol_actual())='administrador');
create policy perfiles_actualizar on public.perfiles for update to authenticated
 using ((select private.rol_actual())='administrador') with check ((select private.rol_actual())='administrador');
create policy categorias_leer on public.categorias for select to authenticated
 using ((select private.rol_actual()) is not null and
 (activo or (select private.rol_actual())='administrador'
 or exists(select 1 from public.ingresos i where i.categoria_id=categorias.id and i.creado_por=(select auth.uid()))
 or exists(select 1 from public.gastos g where g.categoria_id=categorias.id and g.creado_por=(select auth.uid()))));
create policy categorias_insertar on public.categorias for insert to authenticated
 with check ((select private.rol_actual())='administrador');
create policy categorias_actualizar on public.categorias for update to authenticated
 using ((select private.rol_actual())='administrador') with check ((select private.rol_actual())='administrador');
create policy bitacora_leer on public.bitacora for select to authenticated
 using ((select private.rol_actual())='administrador');


grant insert(id,fecha,concepto,monto,categoria_id,referencia,solicitud_id),
 update(fecha,concepto,monto,categoria_id,referencia,estado,motivo_anulacion) on public.ingresos to authenticated;
create policy ingresos_leer on public.ingresos for select to authenticated
 using ((select private.rol_actual()) is not null and (creado_por=(select auth.uid()) or (select private.rol_actual())='administrador'));
create policy ingresos_insertar on public.ingresos for insert to authenticated
 with check ((select private.rol_actual()) is not null and creado_por=(select auth.uid()) and estado='vigente');
create policy ingresos_actualizar on public.ingresos for update to authenticated
 using ((select private.rol_actual()) is not null and estado='vigente' and (creado_por=(select auth.uid()) or (select private.rol_actual())='administrador'))
 with check ((select private.rol_actual()) is not null and (creado_por=(select auth.uid()) or (select private.rol_actual())='administrador'));


grant insert(id,fecha,concepto,monto,categoria_id,referencia,solicitud_id),
 update(fecha,concepto,monto,categoria_id,referencia,estado,motivo_anulacion) on public.gastos to authenticated;
create policy gastos_leer on public.gastos for select to authenticated
 using ((select private.rol_actual()) is not null and (creado_por=(select auth.uid()) or (select private.rol_actual())='administrador'));
create policy gastos_insertar on public.gastos for insert to authenticated
 with check ((select private.rol_actual()) is not null and creado_por=(select auth.uid()) and estado='vigente');
create policy gastos_actualizar on public.gastos for update to authenticated
 using ((select private.rol_actual()) is not null and estado='vigente' and (creado_por=(select auth.uid()) or (select private.rol_actual())='administrador'))
 with check ((select private.rol_actual()) is not null and (creado_por=(select auth.uid()) or (select private.rol_actual())='administrador'));


create view public.v_movimientos with (security_invoker=true) as
 select id,'ingreso'::text as tipo,fecha,concepto,monto,categoria_id,creado_por,estado,revision from public.ingresos
 union all
 select id,'gasto'::text as tipo,fecha,concepto,monto,categoria_id,creado_por,estado,revision from public.gastos;
revoke all on public.v_movimientos from public,anon;grant select on public.v_movimientos to authenticated;

create function public.resumen_financiero(p_desde date,p_hasta date) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare i numeric;g numeric;ni bigint;ng bigint;
begin
 if private.rol_actual() is null then raise exception 'Cuenta no autorizada' using errcode='42501';end if;
 if p_desde is null or p_hasta is null or not isfinite(p_desde) or not isfinite(p_hasta) or p_desde>p_hasta or p_hasta-p_desde>3660 then
  raise exception 'Rango inválido; máximo 3660 días' using errcode='22023';end if;
 select coalesce(sum(monto) filter(where tipo='ingreso'),0),coalesce(sum(monto) filter(where tipo='gasto'),0),count(*) filter(where tipo='ingreso'),count(*) filter(where tipo='gasto')
 into i,g,ni,ng from public.v_movimientos where fecha between p_desde and p_hasta and estado='vigente';
 return jsonb_build_object('desde',p_desde,'hasta',p_hasta,'moneda','USD','ingresos',i,'gastos',g,'resultado',i-g,'porcentaje_gastos',case when i>0 then round(g/i*100,2) else null end,'cantidad_ingresos',ni,'cantidad_gastos',ng);
end $$;
create function public.reporte_movimientos(p_desde date,p_hasta date,p_categoria_id uuid default null,p_tipo text default null)
returns table(id uuid,tipo text,fecha date,concepto text,monto numeric,categoria_id uuid,codigo_categoria text,categoria text,creado_por uuid)
language plpgsql stable security invoker set search_path='' as $$
begin
 if private.rol_actual() is null then raise exception 'Cuenta no autorizada' using errcode='42501';end if;
 if p_desde is null or p_hasta is null or not isfinite(p_desde) or not isfinite(p_hasta) or p_desde>p_hasta or p_hasta-p_desde>3660 or (p_tipo is not null and p_tipo not in ('ingreso','gasto')) then
  raise exception 'Filtros inválidos' using errcode='22023';end if;
 return query select m.id,m.tipo,m.fecha,m.concepto,m.monto,m.categoria_id,c.codigo,c.nombre,m.creado_por
 from public.v_movimientos m join public.categorias c on c.id=m.categoria_id
 where m.estado='vigente' and m.fecha between p_desde and p_hasta
 and (p_categoria_id is null or m.categoria_id=p_categoria_id) and (p_tipo is null or m.tipo=p_tipo)
 order by m.fecha,m.id;
end $$;
create function public.reporte_periodico(p_desde date,p_hasta date,p_granularidad text default 'mes')
returns table(periodo date,ingresos numeric,gastos numeric,resultado numeric,porcentaje_gastos numeric)
language plpgsql stable security invoker set search_path='' as $$
declare unidad text;paso interval;
begin
 if private.rol_actual() is null then raise exception 'Cuenta no autorizada' using errcode='42501';end if;
 if p_desde is null or p_hasta is null or not isfinite(p_desde) or not isfinite(p_hasta) or p_desde>p_hasta or p_hasta-p_desde>3660 or p_granularidad is null or p_granularidad not in ('dia','mes','anio') then
  raise exception 'Rango o granularidad inválida' using errcode='22023';end if;
 unidad:=case p_granularidad when 'dia' then 'day' when 'mes' then 'month' else 'year' end;
 paso:=case p_granularidad when 'dia' then interval '1 day' when 'mes' then interval '1 month' else interval '1 year' end;
 return query
 with series as (select generate_series(date_trunc(unidad,p_desde::timestamp),date_trunc(unidad,p_hasta::timestamp),paso)::date as p),
 totals as (select date_trunc(unidad,m.fecha::timestamp)::date as p,
 coalesce(sum(m.monto) filter(where m.tipo='ingreso'),0) as i,
 coalesce(sum(m.monto) filter(where m.tipo='gasto'),0) as g
 from public.v_movimientos m where m.estado='vigente' and m.fecha between p_desde and p_hasta group by 1)
 select s.p,coalesce(t.i,0),coalesce(t.g,0),coalesce(t.i,0)-coalesce(t.g,0),case when t.i>0 then round(t.g/t.i*100,2) else null end
 from series s left join totals t on t.p=s.p order by s.p;
end $$;
revoke all on function public.resumen_financiero(date,date) from public,anon;
revoke all on function public.reporte_movimientos(date,date,uuid,text) from public,anon;
revoke all on function public.reporte_periodico(date,date,text) from public,anon;
grant execute on function public.resumen_financiero(date,date),public.reporte_movimientos(date,date,uuid,text),public.reporte_periodico(date,date,text) to authenticated;
insert into public.bitacora(accion,entidad,motivo,despues)
values('MIGRACION','sistema','Adaptación a siete módulos con conservación del diseño anterior',jsonb_build_object('categorias',26,'tablas_operativas',5,'archivo','legacy_anf_20261020'));
notify pgrst,'reload schema';
