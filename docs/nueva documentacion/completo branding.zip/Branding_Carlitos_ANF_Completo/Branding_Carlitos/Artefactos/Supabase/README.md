# Base de datos objetivo ANF

**MIGRACIÓN APLICADA Y VERIFICADA EN SUPABASE.** Versión `20261021041732`, nombre `adaptar_carlitos_siete_modulos_anf`. Las 52 comprobaciones locales se complementaron con verificación estructural, permisos, asesor de seguridad sin hallazgos y tipos TypeScript del esquema real.

## Cambio aplicado

Se conservaron veinte tablas, dos vistas y doce funciones del diseño anterior a `legacy_anf_20261020`, conservar sus semillas y revocar acceso de PUBLIC/anon/authenticated/service_role al archivo. Crear cinco tablas operativas públicas (perfiles, categorias, ingresos, gastos y bitacora), RLS, índices, disparadores, una vista invoker y tres RPC invoker. Cargar 26 categorías y un evento de migración; no cargar movimientos ni usuarios ficticios.

El cambio se aplicó tras autorización y nueva inspección. Las aplicaciones que aún consulten el modelo anterior deben adaptarse al esquema nuevo. Los JSON de inspección no son un respaldo restaurable completo. Obtener respaldo PostgreSQL antes de aplicar.

## Archivos

- `01_migracion_siete_modulos.sql`: SQL ya aplicado como una migración transaccional completa. No es idempotente: no volver a ejecutarlo.
- `02_primer_administrador.sql.example`: ejemplo deliberadamente bloqueado por marcador; usar solo después de crear y verificar una identidad real.
- `catalogo_categorias.json`: 26 categorías operativas exactas del Word.
- `catalogo_contable_referencia.json`: 47 cuentas de referencia académica; no es un módulo adicional.
- `resultado_pruebas_locales.json`: resultados de 52 comprobaciones en PGlite, con Auth simulado.
- `pruebas_locales`: prueba reproducible local con columnas/semillas y objetos auxiliares mínimos del esquema anterior.

Leer el contexto 02 para campos, permisos, alta de usuarios, límites de las pruebas y verificación remota realizada y pruebas de integración pendientes. No incluir secretos en esta carpeta. Las claves privilegiadas se mantienen en servidor.

- `verificacion_remota.json`: evidencia de aplicación, estructura, asesores y permisos.
- `database.types.ts`: tipos TypeScript generados desde el proyecto después del cambio.

Pendiente: primera cuenta administrativa real e integración de la aplicación. No se crearon cuentas ni movimientos ficticios.
