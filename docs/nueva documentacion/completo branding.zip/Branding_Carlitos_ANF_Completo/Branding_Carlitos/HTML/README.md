# Ejemplo local de interfaz

Extraer el ZIP completo y abrir `index.html` en un navegador moderno. Mantener Assets, Logos y Paleta en sus rutas relativas. El ejemplo no requiere servidor ni internet.

Los siete módulos y los datos son simulados. La selección de rol no autentica usuarios. Los cambios se guardan únicamente en el navegador. No introducir datos reales. Para restablecer, ejecutar `CarlitosDemo.reset()` en consola o borrar los datos locales del ejemplo.

Se incluyen captura/edición/anulación de movimientos, categorías y usuarios de demostración, panel, reportes detallados/diarios/mensuales/anuales, CSV del detalle y bitácora local. Edición completa de perfiles/categorías, Auth real y recuperación de contraseña permanecen fuera de este ejemplo. La aplicación final se construirá en React + TypeScript + Vite y consultará Supabase con la migración ya aplicada.

Ver el contexto 03 para el mapa de componentes y las comprobaciones realizadas. El archivo resultado_pruebas_html.json contiene 17 comprobaciones aprobadas en Chromium local. No equivale a una prueba remota con Supabase.
