# Demo navegable
Abrir `index.html` en un navegador. Los 8 módulos están representados como vistas demostrativas y los botones de navegación funcionan. **No es un sistema contable funcional:** no hay autenticación real, base de datos, importación procesada ni exportación real. Los números son ejemplos. Conectar las vistas a Django y PostgreSQL para implementación.
