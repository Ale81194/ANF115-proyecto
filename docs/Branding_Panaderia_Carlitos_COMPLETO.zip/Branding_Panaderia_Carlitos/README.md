# Branding y kit de interfaz — Panadería Carlitos

Kit para el **Sistema de Estados Financieros, Presupuestos y Pronósticos**, diseñado conforme al documento técnico proporcionado.

## Contenido
- `Assets/`: mockups visuales y orientación de iconografía.
- `Logos/`: logo horizontal en tres colores, isotipo y favicon SVG (editables).
- `Paleta/`: colores HEX, tokens CSS/JSON, tipografía y medidas.
- `Artefactos/`: mapa de 28 pantallas, matriz de permisos y componentes.
- `HTML/`: ejemplo navegable, responsive, con vistas de los 8 módulos.
- `Skills/`: instrucciones de branding y prompt reutilizable para desarrollar pantallas.

## Cómo empezar
1. Abrir `HTML/index.html`.
2. Usar `Paleta/tokens.css` como fuente de variables de diseño.
3. Integrar los componentes de la demo en plantillas Django.
4. Respetar `Skills/BRAND_SKILL.md`.

**Advertencia:** Los logos son propuestas originales para el proyecto académico; no se presentan como identidad comercial oficial de Panadería Carlitos. Las imágenes de mockups son referencias conceptuales. El HTML es una demo visual sin backend y con datos ficticios. No incluye licencias de fuentes ni imágenes comerciales de terceros.
