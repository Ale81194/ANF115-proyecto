# Procedencia de los recursos
- `Assets/mockup_*.png`: recursos visuales previamente generados en esta conversación; sirven como inspiración, no como capturas de software implementado.
- `Logos/*.svg`: logos vectoriales originales creados para este paquete. Son propuestas de marca, no el logotipo oficial verificado de la panadería.
- `Paleta/*`, `Skills/*`, `HTML/*`, `Artefactos/*`: guías y ejemplos originales del kit.
- Los ejemplos numéricos en HTML son demostrativos y ficticios.
