# Componentes de interfaz
- `BrandLogo`: SVG horizontal y versión reducida.
- `AppShell`: barra lateral, topbar, zona de contenido y pie.
- `PageHeader`: título, subtítulo, filtros y acciones.
- `MetricCard`: importe, período, variación y fuente.
- `AccountingTree`: código, cuenta padre, naturaleza, nivel, estado.
- `JournalTable`: fecha, asiento, cuenta, debe, haber, diferencia.
- `FinancialStatement`: concepto, notas, período, importe y totales.
- `BudgetGrid`: meses, cuentas, importes y variaciones.
- `ScenarioSelector`: base, optimista, pesimista.
- `ExportDialog`: reporte, período, escenario, formato.
- `AuditAlert`: errores de cuadre y permisos.

## Estados de cada componente
Cargando, sin datos, error, correcto, solo lectura y edición autorizada.
