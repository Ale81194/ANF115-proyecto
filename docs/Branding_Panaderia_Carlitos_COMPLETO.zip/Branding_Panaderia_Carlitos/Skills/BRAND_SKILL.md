# Skill: identidad visual de Panadería Carlitos

## Propósito
Crear pantallas coherentes para el **Sistema de Estados Financieros, Presupuestos y Pronósticos**. El diseño se inspira en la referencia cálida de panadería, pero **no** incorpora ventas, compras, inventario operativo ni planillas como módulos autónomos.

## Reglas obligatorias
1. Fondo crema `#FFFDF9`, panel lateral café `#321B13`, acción principal terracota `#A84D2B`.
2. Marca siempre «Panadería Carlitos», no «El Trigal».
3. Menú por ocho módulos: Usuarios y roles; Catálogo y períodos; Importación y registros; Estados históricos; Presupuestos; Pronósticos y escenarios; Estados proyectados; Análisis y reportes.
4. Toda pantalla financiera muestra período y la etiqueta «Datos simulados · uso académico».
5. Tablas monetarias alineadas a la derecha, USD con dos decimales, negativos visibles; fechas legibles.
6. Balance: Activo = Pasivo + Patrimonio. Si no cuadra, mostrar advertencia, nunca un visto bueno.
7. El usuario de Gerencia consulta y exporta, Analista registra y configura presupuestos, Administrador gestiona permisos y aprueba.
8. Formularios con estados: vacío, cargando, éxito, error, sin resultados, sin permiso.
9. Contraste, navegación con teclado y diseño adaptable; no usar color como único indicador.
10. Los mockups son visuales y sus números no prueban estados financieros conciliados.

## Checklist por pantalla
Título, ruta, filtros, acción primaria, acciones secundarias, tabla/formulario, ayuda contextual, estado vacío, error, control de permisos, etiqueta de simulación y responsive.

## Stack sugerido
Django templates, CSS variables, JS progresivo, Chart.js. Mantener componentes reutilizables: `Sidebar`, `Topbar`, `KpiCard`, `FilterBar`, `DataTable`, `StatusBadge`, `EmptyState`, `ConfirmationModal`.
